package exercise2;

public enum SaleLocation {
    Sietch_Tabr,
    Arrakeen,
    Carthag,
    Barony,
    Cala_City,
    Zimia
}
