package exercise3;

public enum MessageType {
    Meeting,
    Warning,
    Message
}
