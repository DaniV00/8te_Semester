package exercise2;

import java.time.LocalDate;

public record Sale(String sort, LocalDate dateTime, String location) {
}
