package exercise1;

public enum ComponentType {
    ENGINE, FUSE, WIRE, BATTERY, SENSOR;
}
