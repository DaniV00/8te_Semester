package exercise1;

public enum IceCream {
    OASEN_FRUCHTMIX,
    SANDDÜNEN_SCHOKOLADE,
    MELANGE_EIS;
}
