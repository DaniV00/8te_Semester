package exercise3;

public record Pair<T, U>(T first, U second) {}
