package exercise3;

public record Interval(int start, int end) {}
