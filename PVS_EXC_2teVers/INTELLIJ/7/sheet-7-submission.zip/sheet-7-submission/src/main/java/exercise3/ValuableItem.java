package exercise3;

public record ValuableItem(String name, int price, String category) {}
