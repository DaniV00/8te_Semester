# sheet-9

Anders als auf den Blättern zuvor, gibt es auf diesem Blatt keine vorgegebene, automatisierte Tests für die Aufgaben. Sie können allerdings gerne selsbt Tests schreiben, um Ihre Implementierungen zu überprüfen.