# sheet-11

Wie auf Blatt 10, gibt es auf diesem Blatt keine vorgegebene, automatisierte Tests für die Aufgaben. Sie können allerdings gerne selbst Tests schreiben, um Ihre Implementierungen zu überprüfen.
