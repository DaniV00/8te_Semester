
package de.uni_ulm.sp.oop.sose24.sheet11.sudoku;

import javafx.application.Application;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Application.launch(SudokuApp.class, args);
    }
}
