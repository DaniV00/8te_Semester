package de.uni_ulm.sp.oop.sose24.sheet11.sudoku;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SudokuApp extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        // TODO: subtask a
    }
}
