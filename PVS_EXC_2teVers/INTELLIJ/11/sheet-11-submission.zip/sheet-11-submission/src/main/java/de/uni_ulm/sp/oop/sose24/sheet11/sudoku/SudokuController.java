package de.uni_ulm.sp.oop.sose24.sheet11.sudoku;

import javafx.scene.layout.VBox;


public class SudokuController {
    private SudokuBoard board;

    public SudokuController() {
        board = new SudokuBoard();
    }

    public VBox createUI() {
        // TODO subtask b, c, d
        return null;
    }
}
