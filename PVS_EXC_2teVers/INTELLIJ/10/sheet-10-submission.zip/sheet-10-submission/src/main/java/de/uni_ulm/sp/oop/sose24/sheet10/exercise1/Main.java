package de.uni_ulm.sp.oop.sose24.sheet10.exercise1;

public class Main {

}
