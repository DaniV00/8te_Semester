package de.uni_ulm.sp.oop.sose24.sheet10.exercise1.models;

public abstract class Person {
    protected String NAME;
    protected boolean female;
}
