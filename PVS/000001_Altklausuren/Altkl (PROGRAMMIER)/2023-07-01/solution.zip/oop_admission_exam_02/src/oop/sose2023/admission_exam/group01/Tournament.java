package oop.sose2023.admission_exam.group01;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;


public class Tournament {
	
	/**
	 * Diese Map speichert die Spieler, die am Turnier teilnehmen.
	 * Der Schlüssel der Map ist der Name des Spielers.
	 * Der Wert ist das zugehörige Spieler-Objekt selber. 
	 *  
	 */
	private Map<String, Player> players = new HashMap<String, Player>();
	
	/**
	 *  In dieser Liste werden alle Spiele des Turniers gespeichert.
	 */
	private List<Game> games;
	
	public Tournament(List<Player> ps) {
		ps.forEach(x -> this.players.put(x.getName(), x));
	}

	/**
	 *  Die Methode erzeugt 2 Spiele für jeden Spieler gegen jeden Spieler und liefert diese in einer Liste zurück.
	 */
	//TODO: Aufgabe 3
	List<Game> createTournamentGames() {
		
		List<Game> games = new ArrayList<>();
		for (Player p1 : players.values()) {
			for (Player p2 : players.values()) {
				if (p1 != p2) {
					games.add(new Game(p1, p2));
				}
			}
		}
		return games;
	}

	// TODO Aufgabe 2
	class WinComparator implements Comparator<Player> {
		@Override
		public int compare(Player o1, Player o2) {
			if (o1.getWins() != o2.getWins()) {
				return o2.getWins()-o1.getWins();
			}
			return o1.getName().compareTo(o2.getName());
		}
	}

	/**
	 * Die Methode liefert eine sortierte Liste an RankingElementen zurück.
	 * 
	 * Jedes RankingElement beinhaltet den Namen des Spielers und die Anzahl der Siege.
	 * Die Sortierung basiert auf der Anzahl an Siegen.
	 * Das erste Element der Liste ist der Sieger, also der Spieler mit der höchsten Anzahl an Siegen. 
	 */
	//TODO: Aufgabe 2
	public List<RankingElement> computeRanking() {
		Set<Player> ranking = new TreeSet<Player>(new WinComparator());

		ranking.addAll(players.values());
		
		Stream<RankingElement> stream = ranking.stream().map(x -> new RankingElement(x.getName(), x.getWins()));					
		return stream.collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
	}

	/**
	 * Diese Methode führt das Turnier durch, in dem jedes Spiel gespielt wird.
	 * 
	 * Am Ende wird das Ranking ausgegeben. 
	 */
	public void runTournament() {
		games = createTournamentGames();
		for (Game game : games) {

			game.printField();
			game.runGame();
			System.out.println(game.getGameInformation());
		}
		
		System.out.println(computeRanking());
	}
}
