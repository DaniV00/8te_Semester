package oop.sose2023.admission_exam.group01;

//Aufgabe 1
public class RankingElement {

	private String name;
	private int wins;
	
	public RankingElement(String name, int wins) {
		setName(name);
		setWins(wins);
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}
	
	
}
