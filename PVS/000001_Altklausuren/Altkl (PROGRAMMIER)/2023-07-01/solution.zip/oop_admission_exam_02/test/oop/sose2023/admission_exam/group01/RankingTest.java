package oop.sose2023.admission_exam.group01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RankingTest {

	private Tournament tournament;
	private List<Player> players;

	@BeforeEach
	public void init() {
		players = new ArrayList<Player>();
		var p1 = new Player("PlayerA", 'O');
		p1.setWins(0);
		var p2 = new Player("PlayerB", 'X');
		p2.setWins(2);
		var p3 = new Player("PlayerC", 'U');
		p3.setWins(2);
		var p4 = new Player("PlayerD", 'V');
		p4.setWins(7);
		var p5 = new Player("PlayerE", 'W');
		p5.setWins(1);

		players.add(p1);
		players.add(p2);
		players.add(p3);
		players.add(p4);
		players.add(p5);
		tournament = new Tournament(players);
	}

	@Test
	void testPlayerD() {
		var list = tournament.computeRanking();
		assertEquals("PlayerD", list.get(0).getName());
		assertEquals(7, list.get(0).getWins());
	}

	@Test
	void testPlayerA() {
		var list = tournament.computeRanking();
		assertEquals("PlayerA", list.get(4).getName());
		assertEquals(0, list.get(4).getWins());
	}
	
	@Test
	void testPlayerB() {
		var list = tournament.computeRanking();
		assertTrue(list.get(1).getName().equals("PlayerB") || list.get(2).getName().equals("PlayerB"));
		assertTrue(list.get(1).getWins() == 2 || list.get(2).getWins() == 2 );
	}
	
	@Test
	void testPlayerC() {
		var list = tournament.computeRanking();
		assertTrue(list.get(1).getName().equals("PlayerC") || list.get(2).getName().equals("PlayerC"));
		assertTrue(list.get(1).getWins() == 2 || list.get(2).getWins() == 2 );
	}
	
	@Test
	void testPlayerE() {
		var list = tournament.computeRanking();
		assertEquals("PlayerE", list.get(3).getName());
		assertEquals(1, list.get(3).getWins());
	}
	
	@Test
	void testEmptyTournament() {
		var players = new ArrayList<Player>();
		var tournament = new Tournament(players);
		
		var ranking = tournament.computeRanking();
		
		assertEquals(0, ranking.size());		
	}
}
