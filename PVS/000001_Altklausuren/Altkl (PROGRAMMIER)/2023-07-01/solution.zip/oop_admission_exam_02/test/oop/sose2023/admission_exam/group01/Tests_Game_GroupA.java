package oop.sose2023.admission_exam.group01;


import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

@Disabled
@Timeout(5)
public class Tests_Game_GroupA {
	
	private Game game;
	private Player p1;
	private Player p2;
	
	@BeforeEach
	public void init() {
		p1 = new Player("PlayerA", 'O');
		p2 = new Player("PlayerB", 'X');
		game = new Game(p1, p2);
	}

	@Test
	public void initGame() {
		Assert.assertFalse(game.checkWinner());
	}
	
	@Test
	public void testField1() {
		char[][] field={{' ', 'X', ' '},
				        {'O', ' ', ' '},
				        {' ', ' ', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(p1);
		Assert.assertFalse(game.checkWinner());
	}
	
//	@Test
//	public void testField2() {
//		char[][] field={{' ', 'X', ' '},
//				        {'O', ' ', ' '},
//				        {' ', ' ', 'X'}};
//		game.setField(field);
//		game.setCurrentPlayer(0);
//		Assert.assertFalse(game.checkWinner());
//	}
	
	@Test
	public void testField3() {
		char[][] field={{' ', 'X', ' '},
				        {'O', ' ', ' '},
				        {' ', ' ', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(p2);
		Assert.assertFalse(game.checkWinner());
	}	

//	@Test
//	public void testField4() {
//		char[][] field={{' ', 'X', ' '},
//				        {'O', ' ', ' '},
//				        {' ', ' ', 'X'}};
//		game.setField(field);
//		game.setCurrentPlayer(1);
//		Assert.assertFalse(game.checkWinner());
//	}
	
	@Test
	public void testFullField1() {
		char[][] field={{'O', 'X', 'X'},
				        {'X', 'O', 'O'},
				        {'X', 'O', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(p1);
		Assert.assertFalse(game.checkWinner());
	}
	
	@Test
	public void testFullField2() {
		char[][] field={{'O', 'X', 'X'},
				        {'X', 'O', 'O'},
				        {'X', 'O', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(p2);
		Assert.assertFalse(game.checkWinner());
	}
	
//	@Test
//	public void testFullField3() {
//		char[][] field={{'O', 'X', 'X'},
//				        {'X', 'O', 'O'},
//				        {'X', 'O', 'X'}};
//		game.setField(field);
//		game.setCurrentPlayer(0);
//		Assert.assertFalse(game.checkWinner());
//	}
	
//	@Test
//	public void testFullField4() {
//		char[][] field={{'O', 'X', 'X'},
//				        {'X', 'O', 'O'},
//				        {'X', 'O', 'X'}};
//		game.setField(field);
//		game.setCurrentPlayer(1);
//		Assert.assertFalse(game.checkWinner());
//	}
	
	@Test
	public void testVerticalWinner1() {
		char[][] field={{'X', 'X', 'X'},
				        {' ', 'O', 'O'},
				        {' ', ' ', 'O'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testVerticalWinner2() {
		char[][] field={{'O', 'X', ' '},
				        {'O', 'O', 'O'},
				        {'X', ' ', 'O'}};
		game.setCurrentPlayer(p1);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testVerticalWinner3() {
		char[][] field={{'X', ' ', ' '},
				        {'O', ' ', 'O'},
				        {'X', 'X', 'X'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}

	
	@Test
	public void testVerticalWinner4() {
		char[][] field={{'X', 'X', 'X'},
				        {' ', 'O', 'O'},
				        {' ', ' ', 'O'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testVerticalWinner5() {
		char[][] field={{'O', 'X', ' '},
				        {'O', 'O', 'O'},
				        {'X', ' ', 'O'}};
		game.setCurrentPlayer(p1);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testVerticalWinner6() {
		char[][] field={{'X', ' ', ' '},
				        {'O', ' ', 'O'},
				        {'X', 'X', 'X'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testDiagonalWinner1() {
		char[][] field={{'O', 'O', 'X'},
				        {'O', 'X', 'O'},
				        {'X', 'O', 'X'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testDiagonalWinner2() {
		char[][] field={{'O', 'X', ' '},
		                {'X', 'O', 'O'},
		                {'X', ' ', 'O'}};
		game.setCurrentPlayer(p1);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	
	@Test
	public void testDiagonalWinner3() {
		char[][] field={{'O', 'O', 'X'},
				        {'O', 'X', 'O'},
				        {'X', 'O', 'X'}};
		game.setCurrentPlayer(p2);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	@Test
	public void testDiagonalWinner4() {
		char[][] field={{'O', 'X', ' '},
		                {'X', 'O', 'O'},
		                {'X', ' ', 'O'}};
		game.setCurrentPlayer(p1);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	



	
}
