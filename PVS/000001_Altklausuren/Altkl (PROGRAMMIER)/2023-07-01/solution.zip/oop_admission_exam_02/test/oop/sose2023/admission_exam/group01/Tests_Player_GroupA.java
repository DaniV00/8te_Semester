package oop.sose2023.admission_exam.group01;


import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;;

@Disabled
@Timeout(5)
public class Tests_Player_GroupA {

	@Test
	public void playerScructure() {
		try {
			Class<?> playerClass = Class.forName("oop.sose2023.admission_exam.group01.Player");
			Method playerMethods[] = playerClass.getDeclaredMethods();
			Assert.assertEquals(7,playerMethods.length);
		} catch (ClassNotFoundException e) {
			Assert.fail("Player-class not avialable!");
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void playerAttributeScructure() {
		try {
			Class<?> playerClass = Class.forName("oop.sose2023.admission_exam.group01.Player");
			Field[] playerFields= playerClass.getDeclaredFields();
			Assert.assertEquals(3,playerFields.length);
			HashMap<String,String> fieldTypeList=new HashMap<String,String>();
			HashMap<String,Integer> fieldModfierList=new HashMap<String,Integer>();
			for(int i=0;i<playerFields.length;i++) {
				fieldTypeList.put(playerFields[i].getName(),playerFields[i].getType().getSimpleName());
				fieldModfierList.put(playerFields[i].getName(),playerFields[i].getModifiers());
			}
			
			Assert.assertNotNull(fieldTypeList.get("name"));
			Assert.assertNotNull(fieldTypeList.get("mark"));
			Assert.assertNotNull(fieldTypeList.get("wins"));
			
			Assert.assertEquals("String",fieldTypeList.get("name"));
			Assert.assertEquals("char",fieldTypeList.get("mark"));
			Assert.assertEquals("int",fieldTypeList.get("wins"));

			
			Assert.assertTrue(Modifier.isPrivate(fieldModfierList.get("name")));
			Assert.assertTrue(Modifier.isPrivate(fieldModfierList.get("mark")));
			Assert.assertTrue(Modifier.isPrivate(fieldModfierList.get("wins")));

		} catch (ClassNotFoundException e) {
			Assert.fail("Player-class not avialable!");
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void initPlayer() {
		Assert.assertNotNull(new Player("Bob", 'X'));
		Player player=new Player("Bob", 'X');
		Assert.assertEquals("Bob",player.getName());
		Assert.assertEquals('X',player.getMark());
		Assert.assertEquals(0,player.getWins());
	}
	
	@Test
	public void checkPlayerName() {
		Player player=new Player("Bob", 'X');
		player.setName("Alice");
		Assert.assertEquals("Alice",player.getName());
	}
	
	@Test
	public void checkPlayerMark() {
		Player player=new Player("Bob", 'X');
		player.setMark('B');
		Assert.assertEquals('B',player.getMark());
	}
	
	@Test
	public void checkPlayerWinner() {
		Player player=new Player("Bob", 'X');
		player.setWins(3);
		Assert.assertEquals(3,player.getWins());
	}
	
	@Test
	public void checkPlayerIncWinner() {
		Player player=new Player("Bob", 'X');
		player.setWins(-2);
		player.incWins();
		Assert.assertEquals(-1,player.getWins());
		player.incWins();
		Assert.assertEquals(0,player.getWins());
		player.incWins();
		Assert.assertEquals(1,player.getWins());
	}
	


}
