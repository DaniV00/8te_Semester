package oop.sose2023.admission_exam.group01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

@Disabled
@Timeout(5)
public class Tests_Main_GroupA {
	
	private TestGame testGame;
	private Player p1, p2;
	private ArrayList<String> moves;

	@BeforeEach
	public void initalize() {
		p1 = new Player("PlayerA", 'O');
		p2 = new Player("PlayerB", 'X');
		testGame=new TestGame(p1, p2);
		moves = new ArrayList<String>(Arrays.asList("1-1", "2-2", "1-2","3-3","1-3"));
	}

	@Test
	public void noWinner() {
		testGame.setWinner(Optional.empty());
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void winner1() {
		testGame.setTestWinner(true);
		testGame.setWinner(Optional.of(p1));
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void winner2() {
		testGame.setTestWinner(true);
		testGame.setWinner(Optional.of(p2));
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void noWinner2() {
		testGame.setWinner(Optional.empty());
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void winner3() {
		testGame.setTestWinner(true);
		testGame.setWinner(Optional.of(p1));
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void winner4() {
		testGame.setTestWinner(true);
		testGame.setWinner(Optional.of(p2));
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
	}
	
	@Test
	public void checkMoves1() {
		char[][] field={{'O', 'O', 'O'},
                        {' ', 'X', ' '},
                        {' ', ' ', 'X'}};
		
		testGame.setCurrentPlayer(p1);
		testGame.setTestWinner(false);
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		testGame.runGame();
		for(int i=0;i<testGame.getField().length;i++) {
			for(int j=0;j<testGame.getField()[i].length;j++) {
				Assert.assertEquals(field[i][j],testGame.getField()[i][j]);
			}
		}
		
	}
	
}
