package oop.sose2023.admission_exam.group01;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TournamentTests {

	private List<Player> players;

	@BeforeEach
	public void init() {
		players = new ArrayList<Player>();
		var p1 = new Player("PlayerA", 'O');
		var p2 = new Player("PlayerB", 'X');
		var p3 = new Player("PlayerC", 'U');
		var p4 = new Player("PlayerD", 'V');
		players.add(p1);
		players.add(p2);
		players.add(p3);
		players.add(p4);
	}

	@Test
	public void testCreateGames() {
		var tournament = new Tournament(players);

		assertEquals(12, tournament.createTournamentGames().size());
	}

	private Function<Game, Function<Integer, Function<Integer, Boolean>>> checker = game -> p1 -> p2 -> game
			.getPlayers().indexOf(players.get(p1)) == 0 && game.getPlayers().indexOf(players.get(p2)) == 1;

	@Test
	public void testCreateGamesPlayerCheck01() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.anyMatch((x) -> checker.apply(x).apply(0).apply(1)));
	}
	@Test
	public void testCreateGamesPlayerCheck02() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.anyMatch((x) -> checker.apply(x).apply(0).apply(2)));
	}
	@Test
	public void testCreateGamesPlayerCheck03() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.anyMatch((x) -> checker.apply(x).apply(0).apply(3)));
	}
	
	@Test
	public void testCreateGamesPlayerCheckNot10() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.anyMatch((x) -> checker.apply(x).apply(1).apply(0)));
	}
	
	@Test
	public void testCreateGamesPlayerCheckNot20() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.anyMatch((x) -> checker.apply(x).apply(2).apply(0)));
	}
	
	
	@Test
	public void testCreateGamesPlayerCheckNot11() {
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		assertTrue(games.stream()
				.noneMatch((x) -> checker.apply(x).apply(1).apply(1)));
	}

	@Test
	public void testEmptyTournament() {
		var players = new ArrayList<Player>();
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		
		assertEquals(0, games.size());	
	}
	
	@Test
	public void testSinglePlayerTournament() {
		var players = new ArrayList<Player>();
		var p1 = new Player("PlayerA", 'O');
		players.add(p1);
		var tournament = new Tournament(players);
		List<Game> games = tournament.createTournamentGames();
		
		assertEquals(0, games.size());	
	}
}
