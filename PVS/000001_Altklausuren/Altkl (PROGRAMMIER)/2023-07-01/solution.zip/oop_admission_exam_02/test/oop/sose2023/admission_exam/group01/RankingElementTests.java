package oop.sose2023.admission_exam.group01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RankingElementTests {

	@Test
	void testRankingElementConstructor() {
		var rankingElement = new RankingElement("foo", 42);
		assertEquals("foo", rankingElement.getName());
		assertEquals(42, rankingElement.getWins());
	}
	
	@Test
	void testRankingElementSetName() {
		var rankingElement = new RankingElement("foo", 42);
		rankingElement.setName("bar");
		assertEquals("bar", rankingElement.getName());
		assertEquals(42, rankingElement.getWins());
	}
	
	@Test
	void testRankingElementSetWins() {
		var rankingElement = new RankingElement("foo", 42);
		rankingElement.setWins(1895);
		assertEquals("foo", rankingElement.getName());
		assertEquals(1895, rankingElement.getWins());
	}
}
