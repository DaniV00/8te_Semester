package eidi2.sose2022.admission_exam.storage;

public interface IStoreable {
	public int value();
}
