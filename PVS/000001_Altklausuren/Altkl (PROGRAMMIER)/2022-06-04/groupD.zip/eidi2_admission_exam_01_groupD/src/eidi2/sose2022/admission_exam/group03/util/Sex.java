package eidi2.sose2022.admission_exam.group03.util;

public enum Sex {
	FEMALE, MALE, OTHER;
}
