package eidi2.sose2022.admission_exam.group01.util;

public class Tuple<F, S> {
	public F first;
	public S second;
	
	public Tuple(F first, S second) {
		this.first = first;
		this.second = second;
	}
}
