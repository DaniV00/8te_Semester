package oop.sose2023.admission_exam.group01;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;

import oop.sose2023.admission_exam.Main;

public class Tests_Game {
	
	
	Game game=new Game("PlayerA","PlayerB");

	@Test(timeout=5000)
	public void initGame() {
		Assert.assertFalse(game.checkWinner());
	}
	
	@Test(timeout=5000)
	public void testField1() {
		char[][] field={{' ', 'X', ' '},
				        {'O', ' ', ' '},
				        {' ', ' ', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(0);
		Assert.assertFalse(game.checkWinner());
	}
	
	@Test(timeout=5000)
	public void testFullField1() {
		char[][] field={{'O', 'X', 'X'},
				        {'X', 'O', 'O'},
				        {'X', 'O', 'X'}};
		game.setField(field);
		game.setCurrentPlayer(0);
		Assert.assertFalse(game.checkWinner());
	}
	
	@Test(timeout=5000)
	public void testWinner1() {
		char[][] field={{'X', 'X', 'X'},
				        {' ', 'O', 'O'},
				        {' ', ' ', 'O'}};
		game.setCurrentPlayer(1);
		game.setField(field);
		Assert.assertTrue(game.checkWinner());
	}
	
	TestGame testGame=new TestGame("PlayerA","PlayerB");
	ArrayList<String> moves= new ArrayList<String>(Arrays.asList("1-1", "2-2", "1-2","3-3","1-3"));


	@Test(timeout=5000)
	public void noWinner() {
		testGame.setWinner(-2);
		((TestInputManagement)testGame.getMngmt()).setXyPosition(moves);
		Main.runGame(testGame);
	}
	
	@Test(timeout=5000)
	public void playerScructure() {
		try {
			Class<?> playerClass = Class.forName("oop.sose2023.admission_exam.group01.Player");
			Method playerMethods[] = playerClass.getDeclaredMethods();
			Assert.assertEquals(7,playerMethods.length);
		} catch (ClassNotFoundException e) {
			Assert.fail("Player-class not avialable!");
			e.printStackTrace();
		}
		
	}

	
}
