package oop.sose2023.admission_exam;

import oop.sose2023.admission_exam.group01.Game;

public class Main {

	// JavaDocs: https://docs.oracle.com/javase/8/docs/api/allclasses-noframe.html

	/**
	 * Es werden maximal fünf Runden Tic-Tac-Toe gespielt. Hat ein Spieler bereits mehr als 2 mal gewonnen gilt
	 * das Spiel als beendet
	 *  
	 * @param args
	 */
	public static void main(String[] args) {
		Game game=new Game("Alice","Bob");
		
		for(int count=0;count<5;count++) {
			game.printField();
			runGame(game);
			System.out.println(game.getGameInformation());
			game.cleanUp();
			if((game.getPlayers().get(0).getWins()>2)||(game.getPlayers().get(1).getWins()>2)) {
				break;
			}
		}
		game.stopGame();	

	}
	
	/**
	 * 
	 * Es werden die folgenden drei Aktionen so lange durchgeführt bis ein Gewinner feststeht oder das Spielfeld vollständig belegt ist: 1. Eingabe der Koordinaten, 2. Setzen der Markierung auf dem Spielfeld, 3. Evaluation des Spielzustands 
	 * 
	 * @param game Aktuelles Spiel 
	 */
	public static void runGame(Game game) {
		//TODO: Aufgabe 2

		
	}

}

