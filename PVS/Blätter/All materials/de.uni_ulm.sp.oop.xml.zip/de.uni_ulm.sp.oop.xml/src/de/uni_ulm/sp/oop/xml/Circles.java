package de.uni_ulm.sp.oop.xml;

import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Circles
{
	private static Document doc;
	private final static int WIDTH = 2000;
	private final static int HEIGHT = 1000;

	public static void main(String[] args) throws Exception
	{
		DocumentBuilder builder = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder();
		doc = builder.newDocument();

		Element svg = doc.createElement("svg");
		svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
		svg.setAttribute("width", Integer.toString(WIDTH));
		svg.setAttribute("height", Integer.toString(HEIGHT));
		svg.appendChild(makeCircles());
		doc.appendChild(svg);

		Transformer trans = TransformerFactory.newInstance().newTransformer();
		trans.setOutputProperty(OutputKeys.INDENT, "yes");

		trans.transform(new DOMSource(doc), new StreamResult("xml/circles.svg"));

		System.out.println("svg written in xml/circles.svg");
	}

	public static Element makeCircles()
	{
		Element groupNode = doc.createElement("g");
		Random rnd = new Random();

		for (int i = 0; i < 150; i++)
		{
			int x = rnd.nextInt(WIDTH);
			int y = rnd.nextInt(HEIGHT);
			int radius = rnd.nextInt(100);
			int width = rnd.nextInt(30);

			String stroke = getRndColor();
			String fillColor = getRndColor();

			groupNode.appendChild(makeCircle(x, y, radius, stroke, width,
					fillColor));
		}
		return groupNode;
	}

	public static Element makeCircle(int x, int y, int radius, String stroke,
			int width, String fillColor)
	{
		Element circleNode = doc.createElement("circle");
		circleNode.setAttribute("cx", Integer.toString(x));
		circleNode.setAttribute("cy", Integer.toString(y));
		circleNode.setAttribute("r", Integer.toString(radius));
		circleNode.setAttribute("stroke", stroke);
		circleNode.setAttribute("stroke-width", Integer.toString(width));
		circleNode.setAttribute("fill", fillColor);
		return circleNode;
	}

	public static String getRndColor()
	{
		Random rnd = new Random();
		int r = rnd.nextInt(255);
		int g = rnd.nextInt(255);
		int b = rnd.nextInt(255);
		return String.format("#%02x%02x%02x", r, g, b);
	}
}
