package de.uni_ulm.sp.oop.xml;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Loads an XML document and validates its XSD.
 */
public class XSDExample
{
	private static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	private static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
	private static final String LOCATION = "xml/ascii.svg";

	public static void main(String[] args) throws Exception
	{
		// Create an XML document with an XSD
		AsciiTable.createTable(AsciiTable.Schema.XSD, LOCATION);
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		// Enable validation, namespaces and add the schema namespace
		factory.setValidating(true);
		factory.setNamespaceAware(true);
		factory.setAttribute(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);

		DocumentBuilder parser = factory.newDocumentBuilder();
		
		// Set an error handler
		parser.setErrorHandler(new DocumentErrorHandler());
		
		// Start the parsing process
		parser.parse(LOCATION);
		
		System.out.println("Parsing finished.");
	}
}
