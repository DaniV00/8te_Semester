package de.uni_ulm.sp.oop.xml;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Use a SAX parser to parse an XML document.
 * 
 * A SAX parser generates events whenever it starts or finishes parsing an element.
 * This class extends the {@code DefaultHandler} to react to these events.
 * 
 * We will print the content of all text elements inside of g elements with the class "dec".
 */
public class SAXExample extends DefaultHandler
{
	/**
	 * Flag to indicate that the parser is inside of a g element with the "dec" class
	 */
	private boolean inDec = false;
	/**
	 * Flag to indicate that the parser is inside of a text element
	 */
	private boolean inText = false;

	/**
	 * Main method that start the parsing process
	 */
	public static void main(String[] args) throws Exception
	{
		SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
		XMLReader reader = parser.getXMLReader();
		reader.setContentHandler(new SAXExample());
		reader.parse("xml/ascii.svg");
	}
	
	/**
	 * This method gets called when the parser starts parsing an element.
	 * It checks if the element is a g element with the class "dec" or a text element
	 * and sets the appropriate flags.
	 * 
	 * @param qname name of the element (e.g. svg, g or text)
	 * @param attrs attributes of the elemtn (e.g. class)
	 */
	public void startElement(String ns, String name, String qname, Attributes attrs)
	{
		if(qname.equals("g"))
		{
			 String clss = attrs.getValue("class");
			 if(clss != null && clss.equals("dec"))
			 {
				 inDec = true;
			 }
		}
		else if(inDec && qname.equals("text"))
		{
			inText = true;
		}
	}
	
	/**
	 * This method gets called when the parser finishes parsing an element.
	 * It checks if the finished element is a g or text element and unsets the appropriate flag.
	 * 
	 * @param qname name of the element (e.g. svg, g or text)
	 */
	public void endElement(String ns, String name, String qname)
	{
		if(qname.equals("g"))
		{
			inDec = false;
		}
		else if(qname.equals("text"))
		{
			inText = false;
		}
	}
	
	/**
	 * This method gets called when the parser encounters text inside an element.
	 * If the flags for a text element and g element with class "dec" are set,
	 * the method will print the text content.
	 * 
	 * @param ch a lot of text inside the XML document
	 * @param start beginning of the text inside the current XML element
	 * @param length amount of characters inside the current XML element
	 */
	public void characters(char[] ch, int start, int length)
	{
		if(inDec && inText)
		{
			System.out.println(new String(ch, start, length));
		}
	}
}
