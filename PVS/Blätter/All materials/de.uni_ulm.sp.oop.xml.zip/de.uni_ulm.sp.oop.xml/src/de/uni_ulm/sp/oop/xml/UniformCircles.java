package de.uni_ulm.sp.oop.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class UniformCircles
{
	public static void main(String[] args) throws Exception
	{
		DocumentBuilder parser = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder();
		Document doc = parser.parse("xml/circles.svg");

		//uniformCirclesOldFashioned(doc);
		uniformCirclesXPath(doc);

		Transformer trans = TransformerFactory.newInstance().newTransformer();
		trans.setOutputProperty(OutputKeys.INDENT, "yes");
		trans.transform(new DOMSource(doc), new StreamResult(
				"xml/circles_uniformed.svg"));

		System.out.println("svg written in xml/circles_uniformed.svg");
	}

	public static void uniformCirclesOldFashioned(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("circle");
		for (int i = 0; i < nl.getLength(); i++)
		{
			Element text = (Element) nl.item(i);
			text.setAttribute("fill", "#0000FF");
		}
	}

	public static void uniformCirclesXPath(Document doc) throws XPathExpressionException
	{
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression decExpr = xpath.compile("//circle[@r < 50] | //circle[@cx < 600]");
		NodeList nl = (NodeList) decExpr.evaluate(doc, XPathConstants.NODESET);

		for (int i = 0; i < nl.getLength(); i++)
		{
			Element text = (Element) nl.item(i);
			text.setAttribute("fill", "#FF0000");
		}
	}
}
