package de.uni_ulm.sp.oop.xml;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Element;

public class DomExample {
  
  private static Logger logger = Logger.getGlobal();
  
  public static void main(String[] args) throws Exception {
    
    var builder = DocumentBuilderFactory.newDefaultInstance().newDocumentBuilder();
    var doc = builder.parse("xml/ascii.svg");
    
    var root = doc.getDocumentElement();
    logger.setLevel(Level.SEVERE);
    
    findAndOutputDec(root);
    
  }

  private static void findAndOutputDec(Element root) {
    
    logger.info("checking " + root.getTagName());

    var children = root.getChildNodes();
    
    if (root.hasAttribute("class") && root.getAttribute("class").equals("dec"))
    {
      var textElement = (Element) children.item(1);
      logger.info(children.item(1).getClass().getName());
      logger.info("children.getLength: " + children.getLength());
      System.out.println(textElement.getTextContent());
    }
    
    
    for (int i = 0; i < children.getLength(); i++) {
      if (children.item(i) instanceof Element) {
        findAndOutputDec((Element) children.item(i)); 
      }
    }
  }
}
