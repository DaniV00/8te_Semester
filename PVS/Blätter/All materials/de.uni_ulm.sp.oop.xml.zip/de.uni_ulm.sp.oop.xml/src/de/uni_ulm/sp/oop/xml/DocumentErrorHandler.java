package de.uni_ulm.sp.oop.xml;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Generic handler for errors during XML parsing
 */
public class DocumentErrorHandler implements ErrorHandler
{
	/**
	 * Pretty-prints an error to the console
	 * @param type type of the error
	 * @param spe the error
	 */
	private void printException(String type, SAXParseException spe)
	{
		System.err.println(type + ": " + spe.getMessage() +
				" (line: " + spe.getLineNumber() +
				", column: " + spe.getColumnNumber() + ")");
	}

	@Override
	public void error(SAXParseException spe) throws SAXException
	{
		printException("Error", spe);
	}

	@Override
	public void fatalError(SAXParseException spe) throws SAXException
	{
		printException("FatalError", spe);
	}

	@Override
	public void warning(SAXParseException spe) throws SAXException
	{
		printException("Warning", spe);
	}
}
