package de.uni_ulm.sp.oop.xml;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Loads an XML file and validates its DTD
 */
public class DTDExample
{
	private static final String LOCATION = "xml/ascii.svg";

	public static void main(String[] args) throws Exception
	{
		// Create an XML file with a DTD
		AsciiTable.createTable(AsciiTable.Schema.DTD, LOCATION);
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		// The factory will now create validating parsers
		factory.setValidating(true);
		DocumentBuilder parser = factory.newDocumentBuilder();

		// Set an error handler to print out parsing errors
		parser.setErrorHandler(new DocumentErrorHandler());
		
		// Start the parsing process
		parser.parse(LOCATION);
		
		System.out.println("Parsing finished.");
	}

}
