package de.uni_ulm.sp.oop.xml;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * The static methods in this class generate an ASCII-Table in SVG-Format. The created document can
 * have a DTD Doctype called "table.dtd" or an XSD Schema called "table.xsd".
 */
public class AsciiTable {
  /**
   * Global document for SVG generation.
   */
  private static Document doc;

  private static final String NAMESPACE_URI = "http://www.w3.org/2001/XMLSchema-instance";
  private static final String LOCATION_ATTRIBUTE = "xsi:noNamespaceSchemaLocation";

  /**
   * Enumeration of supported Schemata and their file locations.
   */
  public enum Schema {
    DTD("table.dtd"), XSD("table.xsd");

    /**
     * Location of the Schema file.
     */
    public final String file;

    /**
     * Enum constructor.
     */
    Schema(String file) {
      this.file = file;
    }
  }

  /**
   * Main method that generates an ASCII table with DTD doctype.
   */
  public static void main(String[] args) throws Exception {
    createTable(Schema.DTD, "xml/ascii.svg");

    System.out.println("svg written in xml/ascii.svg");
  }

  /**
   * Creates an SVG image displaying an ASCII table.
   * 
   * @param s Schema
   * @param location Name of SVG output file
   */
  public static void createTable(Schema s, String location) throws Exception {
    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
    doc = builder.newDocument();

    // Create the svg element inside the document and append the ASCII
    // tables content
    Element svg = doc.createElement("svg");
    svg.appendChild(makeTable());
    svg.setAttribute("width", "900");
    svg.setAttribute("height", "740");
    doc.appendChild(svg);

    // The transformer transforms the document into an XML string
    TransformerFactory factory = TransformerFactory.newInstance();
    Transformer trans = factory.newTransformer();
    trans.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
    trans.setOutputProperty(OutputKeys.INDENT, "yes");

    // Add doctype or schema
    switch (s) {
      case DTD:
        DOMImplementation domImpl = doc.getImplementation();
        DocumentType docType = domImpl.createDocumentType("doctype", "de.uulm.in.xml", s.file);
        trans.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, docType.getPublicId());
        trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, docType.getSystemId());
        break;
      case XSD:
        svg.setAttributeNS(NAMESPACE_URI, LOCATION_ATTRIBUTE, s.file);
        break;
      default:
        break;
    }

    // Write the transformed XML string to a file
    trans.transform(new DOMSource(doc), new StreamResult(location));
  }

  /**
   * Creates the ASCII table consisting of four columns.
   * 
   * @return Element containing a table
   */
  private static Element makeTable() {
    return makeGroup(50, 50, "table", makeColumn(0, 31, 0, 0), makeColumn(32, 63, 300, 0),
        makeColumn(64, 95, 450, 0), makeColumn(96, 127, 600, 0));
  }

  /**
   * Creates a column consisting of multiple rows and a heading. The column is offset by {@code x}
   * and {@code y} pixels and its content ranges from the characters from {@code from} to {@code to}
   * inclusive.
   * 
   * @param from character start
   * @param to character end (inclusive)
   * @param x offset along x-axis
   * @param y offset along y-axis
   * @return Element containing a column
   */
  private static Element makeColumn(int from, int to, int x, int y) {
    Element[] rows = new Element[to - from + 2];
    rows[0] = makeHeading();

    for (int i = 0; i < rows.length - 1; i++) {
      rows[i + 1] = makeRow(i + from, getCharRep(i + from), 0, 40 + i * 20);
    }
    return makeGroup(x, y, "column", rows);
  }

  /**
   * Creates a heading.
   * 
   * @return Element containing a heading
   */
  private static Element makeHeading() {
    Element decHeading = makeGroup(0, 0, "dec", makeText("Dec", "black"));
    Element charHeading = makeGroup(50, 0, "char", makeText("Char", "black"));

    return makeGroup(0, 0, "heading", decHeading, charHeading);
  }

  /**
   * Creates a row containing the number {@code dec} and the character {@code chr}. The row is
   * offset by {@code x} and {@code y}.
   * 
   * @param dec number to be displayed
   * @param chr character to be displayed
   * @param x offset along x-axis
   * @param y offset along y-axis
   * @return Element containing a row
   */
  private static Element makeRow(int dec, String chr, int x, int y) {
    Element decNode = makeGroup(0, 0, "dec", makeText(Integer.toString(dec), "darkblue"));
    Element chrNode = makeGroup(50, 0, "char", makeText(chr, "darkred"));

    return makeGroup(x, y, "row", decNode, chrNode);
  }

  /**
   * Groups multiple elements into a SVG g (for group) element. Also adds a class and an offset to
   * the g element.
   * 
   * @param x offset along x-axis
   * @param y offset along y-axis
   * @param clss class to add
   * @param children Elements to add into the g element
   * @return SVG g element
   */
  private static Element makeGroup(int x, int y, String clss, Element... children) {
    Element groupNode = doc.createElement("g");
    groupNode.setAttribute("transform", "translate(" + x + "," + y + ")");
    groupNode.setAttribute("class", clss);
    for (Element child : children) {
      groupNode.appendChild(child);
    }
    return groupNode;
  }

  /**
   * Creates a SVG text element with a {@text} and {@color}.
   * 
   * @param text content of the element
   * @param color color of the text
   * @return SVG text element
   */
  private static Element makeText(String text, String color) {
    return makeText(text, color, "Consolas", 20);
  }

  /**
   * Create a SVG text element with a {@text}, {@color}, {@font} and {@size}.
   * 
   * @param text content of the element
   * @param color color of the text
   * @param font font of the text
   * @param size size of the text
   * @return SVG text element
   */
  private static Element makeText(String text, String color, String font, int size) {
    Element textNode = doc.createElement("text");
    textNode.setAttribute("font-family", font);
    textNode.setAttribute("font-size", Integer.toString(size));
    textNode.setAttribute("fill", color);
    textNode.setTextContent(text); // automatically escapes HTML
    return textNode;
  }

  /**
   * Gives the ASCII character (or its description) corresponding to the given number.
   * 
   * @param i number of the requested ASCII character
   * @return ASCII character or its description
   */
  private static String getCharRep(int i) {
    switch (i) {
      case 0:
        return "[null]";
      case 1:
        return "[start of heading]";
      case 2:
        return "[start of text]";
      case 3:
        return "[end of text]";
      case 4:
        return "[end of transmission]";
      case 5:
        return "[enquiry]";
      case 6:
        return "[acknowledge]";
      case 7:
        return "[bell]";
      case 8:
        return "[backspace]";
      case 9:
        return "[horizontal tab]";
      case 10:
        return "[line feed]";
      case 11:
        return "[vertical tab]";
      case 12:
        return "[form feed]";
      case 13:
        return "[carriage return]";
      case 14:
        return "[shift out]";
      case 15:
        return "[shift in]";
      case 16:
        return "[data link escape]";
      case 17:
        return "[device control 1]";
      case 18:
        return "[device control 2]";
      case 19:
        return "[device control 3]";
      case 20:
        return "[device control 4]";
      case 21:
        return "[negative acknowledge]";
      case 22:
        return "[synchronous idle]";
      case 23:
        return "[end of trans block]";
      case 24:
        return "[cancel]";
      case 25:
        return "[end of medium]";
      case 26:
        return "[substitute]";
      case 27:
        return "[escape]";
      case 28:
        return "[file separator]";
      case 29:
        return "[group separator]";
      case 30:
        return "[record separator]";
      case 31:
        return "[unit separator]";
      case 32:
        return "[space]";
      case 127:
        return "[del]";
      default: // 33-126
        return Character.toString((char) i);
    }
  }
}
