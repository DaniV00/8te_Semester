package de.uni_ulm.sp.oop.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


/**
 * Example usage of DOM methods to read and modify an XML document.
 */
public class BigFontExample
{
	public static void main(String[] args) throws Exception
	{
		// Load the contents of "xml/ascii.svg" into a Document
		DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = parser.parse("xml/ascii.svg");

		// Get all text elements from the Document and iterate over them
		NodeList nl = doc.getElementsByTagName("text");
		for(int i = 0; i < nl.getLength(); i++)
		{
			Element text = (Element) nl.item(i);
			text.setAttribute("font-size", "40");
		}
		
		// Write the modified document into a file
		Transformer trans = TransformerFactory.newInstance().newTransformer();
		trans.transform(new DOMSource(doc), new StreamResult("xml/ascii-big-font.svg"));

        System.out.println("svg written in xml/ascii-big-font.svg");
	}
}
