package de.uni_ulm.sp.oop.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * This class uses XPATH to modify all text elements that are children of g elements with certain
 * classes.
 */
public class XPathExample
{
	/**
	 * Modifies ceratain text elements.
	 */
	public static void main(String[] args) throws Exception
	{
		DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document doc = parser.parse("xml/ascii.svg");
		XPath xpath = XPathFactory.newInstance().newXPath();

		// Create an XPATH selector that matches all text elements that are directly contained
		// inside a g element with class "dec" and a g element with class "row"
		XPathExpression decExpr = xpath.compile("//g[@class=\"row\"]/g[@class=\"dec\"]/text");

		// Get a list of all matching elements
		NodeList nl = (NodeList) decExpr.evaluate(doc, XPathConstants.NODESET);
		for(int i = 0; i < nl.getLength(); i++)
		{
			Element dec = (Element) nl.item(i);
			dec.setAttribute("fill", "black");
			dec.setAttribute("font-size", "30");
		}

		// Write the modified document to a file
		Transformer trans = TransformerFactory.newInstance().newTransformer();
		trans.transform(new DOMSource(doc), new StreamResult("xml/ascii-xpath.svg"));

        System.out.println("svg written in xml/ascii-xpath.svg");
	}
}
