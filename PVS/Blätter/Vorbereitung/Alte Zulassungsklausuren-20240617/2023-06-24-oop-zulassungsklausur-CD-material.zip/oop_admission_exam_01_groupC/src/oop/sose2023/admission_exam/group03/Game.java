package oop.sose2023.admission_exam.group03;

import oop.sose2023.admission_exam.group03.util.InputManagement;

import java.util.ArrayList;

public class Game {
	// Spielfeld
	private char[][] field = initializeField();
	// Informationen zu den aktuellen Spielern
	private ArrayList<Player> players;
	// Index des Spielers, der am Zug ist (aktueller Spieler)
	private int currentPlayer = 0;
	// Spielzustand: 1. Zustand -1=kein Gewinner, 2. Zustand -2=unentschieden, weil
	// kein Zug mehr möglich ist, 3. Index des Spielers der die aktuelle Runde
	// gewonnen hat.
	private int winner = -1;
	// Manager für die Konsoleneingabe
	private InputManagement mngmt;

	/**
	 * Erzeugt ein neues Spielfeld.
	 * 
	 * @return Spielfeld
	 */
	private char[][] initializeField() {
		char[][] board = new char[6][7]; // 7 columns, 6 rows in board, columns go from left to right, rows from top
											// to bottom
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				board[i][j] = ' ';
			}
		}
		return board;
	}

	/**
	 * Erzeugt ein neues Spiel und initialisiert dazu die Spieler sowie den
	 * InputManager für die Konsoleneingabe der Koordinaten.
	 * 
	 * @param namePlayer1 Name des 1. Spielers
	 * @param namePlayer2 Name des 2. Spielers
	 */
	public Game(String namePlayer1, String namePlayer2) {
		this.players = new ArrayList<Player>();
		this.players.add(new Player(namePlayer1, 'o'));
		this.players.add(new Player(namePlayer2, 'x'));
		this.mngmt = new InputManagement();
	}

	/**
	 * Überprüft ob ein Spieler mit einer horizontalen Reihe von Steinen gewonnen hat.
	 * 
	 */
	private boolean horizontalWin() {
		for (int i = 0; i < field.length; i++) {
			for (int j = 0; j <= field[0].length - 4; j++) {
				char currentMark = field[i][j];
				if (currentMark != ' ' && currentMark == field[i][j + 1] && currentMark == field[i][j + 2]
						&& currentMark == field[i][j + 3]) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Überprüft ob ein Spieler mit einer vertikalen Reihe von Steinen gewonnen hat.
	 * 
	 */
	private boolean verticalWin() {
		//TODO: Aufgabe 3
	}

	/**
	 * Überprüft ob ein Spieler mit einer diagonalen Reihe von Steinen gewonnen hat, die
	 * von links unten (5,0) nach rechts oben (0,6) steigt.
	 * 
	 */
	private boolean diagonalBLtoURWin() {
		for (int i = field.length - 1; i >= field.length - 3; i--) { // (5 -> 0)
			for (int j = 0; j <= field[0].length - 4; j++) { // (0 -> 3)
				char currentMark = field[i][j];
				if (currentMark != ' ' && currentMark == field[i - 1][j + 1] && currentMark == field[i - 2][j + 2]
						&& currentMark == field[i - 3][j + 3]) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Überprüft ob ein Spieler mit einer diagonalen Reihe von Steinen gewonnen hat, die
	 * von rechts unten (5,6) nach links oben (0,0) steigt.
	 * 
	 */
	private boolean diagonalBRtoULWin() {
		//TODO: Aufgabe 3
	}

	/**
	 * Pr�ft ob der aktuelle Spieler gewonnen hat.
	 * 
	 * @return Wahr, wenn der aktuelle Spieler gewonnen hat, sonst Falsch
	 */
	public boolean checkWinner() {
		// TODO: Aufgabe 3
	}

	/**
	 * �berpr�ft den aktuellen Spielzustand und aktualisiert diesen. Die Methode
	 * pr�ft, ob noch freie Felder auf dem Spielfeld vorhanden sind und ob ein
	 * Spieler gewonnen hat. Hat ein Spieler gewonnen wird dieser als Gewinner
	 * gesetzt und die Anzahl seiner Siege inkrementiert. Zuletzt wird der Zustand
	 * des aktuellen Spielers aktualisiert, damit der andere Spieler nun der
	 * aktuelle Spieler ist.
	 */
	public void evaluateGameState() {
		boolean freeField = false;
		for (int i = 0; i < this.field.length; i++) {
			for (int j = 0; j < this.field[i].length; j++) {
				if (this.field[i][j] == ' ') {
					freeField = true;
					break;
				}
			}
			if (freeField) {
				break;
			}
		}
		if (!freeField) {
			this.winner = -2;
		}
		if (checkWinner()) {
			this.winner = this.currentPlayer;
			this.players.get(this.currentPlayer).incWins();
		}
		this.toogleCurrentPlayer();
	}

	/**
	 * Gibt den nächsten freien Platz einer Spalte zurück.
	 * 
	 * @param column
	 * @return Die Zeile des freien Platzes. -1 falls es keine gibt
	 */
	private int getNextFreePlace(int column) {
		for (int i = this.field.length - 1; i >= 0; i--) {
			if (this.field[i][column] == ' ') {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Setzt die Farbe des aktuellen Spielers an die unterste freie Stelle der
	 * angegebene Spielfeldspalte.
	 *
	 * @param column Die Ziel Spalte
	 */
	public void dropToken(int column) {
		if (this.winner < 0) {
			if (isColumnFree(column)) {
				int free = getNextFreePlace(column);
				field[free][column] = this.players.get(this.currentPlayer).getMark();
			}
			this.printField();
		}
	}

	/**
	 * Holt �ber den InputManager die Konsoleneingabe der Zielspalte
	 * 
	 * @return int mit der Position der Zielspalte
	 */
	public int getColumn() {
		return this.mngmt.manageInput(this);
	}

	/**
	 * Prüft, ob die angegebene Spalte bereits voll belegt ist
	 * 
	 * @param column Zielspalte
	 * @return Wahr, wenn die angegebene Spalte noch nicht voll ist, sonst Falsch
	 */
	public boolean isColumnFree(int column) {
		return (getNextFreePlace(column) != -1);
	}

	/**
	 * Entfernt alle gesetzten Symbole von dem Spielfeld, legt den neuen aktuellen
	 * Spieler fest und setzt den Spielzustand erneut auf "keinen Gewinner" (-1)
	 */
	public void cleanUp() {
		field = initializeField();
		if (this.winner == this.currentPlayer) {
			this.toogleCurrentPlayer();
		}
		this.winner = -1;
	}

	/**
	 * Erzeugt eine Konsolenausgabe des Spielfelds.
	 */
	public void printField() {
		for (int j = 0; j <= this.field.length - 1; j++) {
			for (int i = 0; i < this.field[0].length; i++) {
				System.out.print("|");
				System.out.print(this.field[j][i]);
			}
			System.out.print("|");
			System.out.println();
		}
	}

	/**
	 * Erzeugt einen Informationstext �ber den Ausgang einer Spielrunde.
	 * 
	 * @return Information �ber den Ausgang der aktuellen Runde.
	 */
	public String getGameInformation() {
		String msg = "";
		if (winner == -2) {
			msg = "Game over. No winner!";
		} else {
			this.toogleCurrentPlayer();
			msg = this.players.get(winner).getName() + " won for the " + this.players.get(winner).getWins() + ". time";
		}
		return msg;
	}

	/**
	 * Aktualisiert im Attribut currentPlayer den Index des aktuellen Spielers.
	 */
	private void toogleCurrentPlayer() {
		this.currentPlayer = ((this.currentPlayer == 0) ? 1 : 0);
	}

	public char[][] getField() {
		return this.field;
	}

	public void setField(char[][] field) {
		this.field = field;
	}

	public ArrayList<Player> getPlayers() {
		return this.players;
	}

	public void setPlayer(ArrayList<Player> players) {
		this.players = players;
	}

	public int getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public int getWinner() {
		return this.winner;
	}

	public void setWinner(int winner) {
		this.winner = winner;
	}

	public void stopGame() {
		this.mngmt.closeInput();
	}

	public InputManagement getMngmt() {
		return mngmt;
	}

	public void setMngmt(InputManagement mngmt) {
		this.mngmt = mngmt;
	}

}
