package oop.sose2023.admission_exam.group03.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import oop.sose2023.admission_exam.group03.Game;

public class InputManagement {
	
	private BufferedReader bufferReader;
	
	/**
	 * 
	 * Implementiert das Einlesen der Zielspalte über die Konsole und die Aufbereitung des dadurch erhaltenen Strings. Bei einer Falscheingabe wird der aktuelle Spieler aufgefordert erneut eine Spalte einzugeben.
	 * 
	 * @param game Aktuelles Spiel, f�r das Koordinaten als Konsoleneingabe erwartet werden
	 * @return int mit der Zielspalte
	 */
	public int manageInput(Game game) {
		int column = -1;
		bufferReader = new BufferedReader(new InputStreamReader(System.in));	
		try{
			while(column == -1) {
				System.out.print(this.getPlayerInformation(game));
				String input = bufferReader.readLine();
				column=getInput(game, input);
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	
		return column;
	}
	
	/**
	 * Schlie�t den Stream, der verwendet wird um die Zielspalte �ber die Konsole einzulesen.
	 */
	public void closeInput() {
		try {
			bufferReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Extrahiert aus den in input übergebenen Text die Zielspalte als int.
	 * 
	 * @param game Aktuelles Spiel, f�r das die Zielspalte als Konsoleneingabe erwartet wird
	 * @param input Über die Konsole eingegebene Spalte.
	 * @return int Mit dem aufbereiteten Input. Im Fehlerfall wird -1 zurück gegeben
	 */
	private int getInput(Game game,String input) {
		int column= -1;
			try {
				int c=Integer.parseInt(input);
				if(1 <= c && c <= 7 && game.isColumnFree(c-1)) {
					column=c-1;
				}
				
			}catch(NumberFormatException e) {
				return column;
			}
		
		return column;
	}
	
	/**
	 * Erzeugt den Text f�r eine Eingabeaufforderung an den aktuellen Spieler
	 * 
	 * @param game Aktuelles Spiel, f�r das Koordinaten als Konsoleneingabe erwartet werden
	 * @return Text zur Eingabeaufforderung an den aktuellen Spieler
	 */
	private String getPlayerInformation(Game game) {
		String msg="";
		msg=game.getPlayers().get(game.getCurrentPlayer()).getName()+" it is your turn. Please enter the column you want to drop your token in (Please note 1<=column<=7): ";
		return msg;
	}

}
