package oop.sose2023.admission_exam.group03;

//TODO: Aufgabe 1
public class Player {
	
}
