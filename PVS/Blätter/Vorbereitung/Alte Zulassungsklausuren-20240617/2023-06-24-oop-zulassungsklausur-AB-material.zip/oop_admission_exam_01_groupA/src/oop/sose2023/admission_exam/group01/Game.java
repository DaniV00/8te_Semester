package oop.sose2023.admission_exam.group01;

import java.util.ArrayList;

import oop.sose2023.admission_exam.group01.util.InputManagement;

public class Game {
	
	//Spielfeld
	private char[][] field={{' ', ' ', ' '},{' ', ' ', ' '},{' ', ' ', ' '}};
	//Informationen zu den aktuellen Spielern
	private ArrayList<Player> players;
	//Index des Spielers, der am Zug ist (aktueller Spieler)
	private int currentPlayer=0;
	//Spielzustand: 1. Zustand -1=kein Gewinner, 2. Zustand -2=unentschieden, weil kein Zug mehr möglich ist, 3. Index des Spielers der die aktuelle Runde gewonnen hat.
	private int winner=-1; 
	// Manager für die Konsoleneingabe
	private InputManagement mngmt;
	

	/**
	 * Erzeugt ein neues Spiel und initialisiert dazu die Spieler sowie den InputManager für die Konsoleneingabe der Koordinaten.
	 * 
	 * @param namePlayer1 Name des 1. Spielers
	 * @param namePlayer2 Name des 2. Spielers
	 */
	public Game(String namePlayer1, String namePlayer2) {
		this.players=new ArrayList<Player>();
		this.players.add(new Player(namePlayer1,'O'));
		this.players.add(new Player(namePlayer2,'X'));
		this.mngmt=new InputManagement();
	}
	
	/**
	 * Prüft ob der aktuelle Spieler gewonnen hat.
	 * 
	 * @return Wahr, wenn der aktuelle Spieler gewonnen hat, sonst Falsch
	 */
	public boolean checkWinner() {
		//TODO: Aufgabe 3


	}
	
	/**
	 * Überprüft den aktuellen Spielzustand und aktualisiert diesen. 
	 * Die Methode prüft, ob noch freie Felder auf dem Spielfeld vorhanden sind und ob ein Spieler gewonnen hat.
	 * Hat ein Spieler gewonnen wird dieser als Gewinner gesetzt und die Anzahl seiner Siege inkrementiert.
	 * Zuletzt wird der Zustand des aktuellen Spielers aktualisiert, damit der andere Spieler nun der aktuelle Spieler ist.  
	 */
	public void evaluateGameState() {
		boolean freeField=false;
		for(int i=0;i<this.field.length;i++) {
			for(int j=0;j<this.field[i].length;j++) {
				if(this.field[i][j]==' ') {
					freeField=true;
					break;
				}
			}
			if(freeField) {
				break;
			}
		}
		if(!freeField) {
			this.winner=-2;
		}
		if(checkWinner()) {
			this.winner=this.currentPlayer;
			this.players.get(this.currentPlayer).incWins();
		}
		this.toogleCurrentPlayer();
	}
	
	/**
	 * Setzt das Symbol des aktuellen Spielers an die angegebene Stelle im Spielfeld. Es werden als Koordinaten Werte zwischen 1-3 erwartet.
	 * 
	 * @param x x-Koordinate im Spielfeld
	 * @param y y-Koordinate im Spielfeld
	 */
	public void setMark(int x,int y) {
		if((x>0)&&(y>0)&&(this.field[x-1][y-1]==' ')) {
			this.field[x-1][y-1]=this.players.get(this.currentPlayer).getMark();	
		}
		this.printField();
	}

	/**
	 * Holt über den InputManager die Konsoleneingabe der x- und y-Koordinaten
	 * 
	 * @return Array [x,y] mit den x- und y-Koordinaten auf einem Spielfeld
	 */
	public int[] getPosition() {
		return this.mngmt.manageInput(this);
	}
	
	/**
	 * Prüft, ob die angegebene Stelle im Spielfeld bereits belegt ist. Es werden als Koordinaten Werte zwischen 1-3 erwartet.
	 * 
	 * @param x x-Koordinate im Spielfeld
	 * @param y y-Koordinate im Spielfeld
	 * @return  Wahr, wenn die angegebene Position im Spielfeld noch nicht belegt ist, sonst Falsch
	 */
	public boolean isFieldFree(int x,int y) {
		return (this.field[x-1][y-1]==' ');
	}

	/**
	 * Entfernt alle gesetzten Symbole von dem Spielfeld, legt den neuen aktuellen
	 *  Spieler fest und setzt den Spielzustand erneut auf "keinen Gewinner" (-1) 
	 */
	public void cleanUp() {
		for(int i=0;i<this.field.length;i++) {
			for(int j=0;j<this.field[i].length;j++) {
				this.field[i][j]=' ';
			}
		}
		if(this.winner==this.currentPlayer) {
			this.toogleCurrentPlayer();
		}
		this.winner=-1;
	}
	
	/**
	 * Erzeugt eine Konsolenausgabe des Spielfelds.
	 */
	public void printField() {
		for(int i=0;i<this.field.length;i++) {
			System.out.print("|");
			for(int j=0;j<this.field[i].length;j++) {
				System.out.print(this.field[i][j]);
				if(j<2) {
					System.out.print("| ");
				}else {
					System.out.println("|");
				}
			}
		}
		
	}
	
	/**
	 * Erzeugt einen Informationstext über den Ausgang einer Spielrunde.
	 * 
	 * @return Information über den Ausgang der aktuellen Runde.
	 */
	public String getGameInformation() {
		String msg="";
		if(winner==-2) {
			msg="Game over. No winner!";
		}else {
			this.toogleCurrentPlayer();
			msg=this.players.get(this.currentPlayer).getName()+" won for the "+this.players.get(this.currentPlayer).getWins()+". time";
		}
		return msg;
	}

	/**
	 * Aktualisiert im Attribut currentPlayer den Index des aktuellen Spielers.
	 */
	private void toogleCurrentPlayer() {
		this.currentPlayer=((this.currentPlayer == 0) ? 1 : 0);
	}
		
	public char[][] getField() {
		return this.field;
	}

	public void setField(char[][] field) {
		this.field = field;
	}

	public ArrayList<Player> getPlayers() {
		return this.players;
	}

	public void setPlayers(ArrayList<Player> players) {
		this.players = players;
	}

	public int getCurrentPlayer() {
		return currentPlayer;
	}

	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public int getWinner() {
		return this.winner;
	}

	public void setWinner(int winner) {
		this.winner = winner;
	}

	public void stopGame() {
		this.mngmt.closeInput();
	}
	
	public  InputManagement getMngmt() {
		return mngmt;
	}

	public void setMngmt(InputManagement mngmt) {
		this.mngmt = mngmt;
	}

}
