package oop.sose2023.admission_exam.group01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RankingElementTests_Exam {

	
	@Test
	void testRankingElementSetName() {
		var rankingElement = new RankingElement("foo", 42);
		rankingElement.setName("bar");
		assertEquals("bar", rankingElement.getName());
		assertEquals(42, rankingElement.getWins());
	}
	
}
