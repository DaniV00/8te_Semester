package oop.sose2023.admission_exam.group01;

public class TestGame extends Game {
	
	private boolean testWinner=false;

	public TestGame(Player p1, Player p2) {
		super(p1, p2);
		this.setMngmt(new TestInputManagement());
	}
	
	public boolean checkWinner() {
		return this.testWinner;
	}

	public boolean isTestWinner() {
		return testWinner;
	}

	public void setTestWinner(boolean testWinner) {
		this.testWinner = testWinner;
	}

}
