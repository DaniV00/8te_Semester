package oop.sose2023.admission_exam.group01;

//TODO: Aufgabe 1
public class RankingElement {
	
}
