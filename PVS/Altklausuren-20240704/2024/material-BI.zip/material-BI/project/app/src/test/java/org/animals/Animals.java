/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.animals;


class Animals {
   private Animals() {}
   
   
   static final Animal horsie = new Animal("Horse", "Ursula", 5) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.HAY; }
         public int quantity() { return 5; }
      }; }
   };
   
   static final Animal horsie2 = new Animal("Horse", "Jens", 7) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.HAY; }
         public int quantity() { return 4; }
      }; }
   };
   
   static final Animal pengu = new Animal("Penguin", "Flo", 2) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.FISH; }
         public int quantity() { return 2; }
      }; }
   };
   
   static final Animal pengu2 = new Animal("Penguin", "Jeff", 13) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.FISH; }
         public int quantity() { return 1; }
      }; }
   };
   
   static final Animal dietPengu = new Animal("Penguin", "Tia", 19) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.FISH; }
         public int quantity() { return 0; }
      }; }
   };
   
   
   static final Animal eleph = new Animal("Elephant", "Tommy", 10) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.GRAIN; }
         public int quantity() { return 10; }
      }; }
   };
   
   static final Animal eleph2 = new Animal("Elephant", "Gustav", 10) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.HAY; }
         public int quantity() { return 12; }
      }; }
   };
   
   static final Animal eleph3 = new Animal("Elephant", "Haley", 10) {
      @Override
      Food getFood() { return new Food() {
         public FoodType type() { return FoodType.HAY; }
         public int quantity() { return 8; }
      }; }
   };
   
}
