package org.animals;

import java.util.Collection;
import java.util.Map;

import org.animals.Food.FoodType;

public interface Preserve<A extends Animal> {
   boolean addAnimal(A animal);
   
   void feedAnimals(Map<FoodType, Integer> foodQuantities);
   
   Collection<A> getAnimals();
}
