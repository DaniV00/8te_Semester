package org.animals;

import java.io.IOException;
import java.util.Map;
import java.io.Reader;

import org.animals.Food.FoodType;


public class FoodConfigurationReader {
   // Note: You can change the type of this attribute
   private Reader reader;
   
   public FoodConfigurationReader(Reader reader) {
      this.reader = reader;
   }
   
   public Map<FoodType, Integer> readConfiguration() throws IOException {
      // 3a) TODO: Implement this method to read the configuration from the reader
      return null;   
   }
}
