/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.animals;

import java.io.IOException;
import java.io.StringReader;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.animals.Food.FoodType;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith({ Global.class })
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task3Tests {
   
   public static Stream<Arguments> simpleValidConfigurations() {
      return Stream.of(
            Arguments.of("", 0, 0, 0),
            Arguments.of("3 FISH\n5 HAY\n7 GRAIN\n", 3, 5, 7),
            Arguments.of("0 FISH\n0 HAY\n0 GRAIN\n", 0, 0, 0),
            Arguments.of("1 FISH\n2 HAY\n3 GRAIN\n", 1, 2, 3),
            Arguments.of("1 FISH\n2 FISH", 3, 0, 0),
            Arguments.of("1 FISH\n2 HAY\n\n\n\n3 GRAIN\n\n\n", 1, 2, 3),
            Arguments.of("2 HAY\n2 HAY\n2 HAY", 0, 6, 0),
            Arguments.of("99 FISH", 99, 0, 0)
      );
   }
   
   @ParameterizedTest
   @Order(1)
   @DisplayName("[Task 3a, 0.5p each] Should be able to read this valid configuration")
   @MethodSource("simpleValidConfigurations")
   void constructorShouldCreateAnEmptyCollection(String config, int fish, int hay, int grain) throws IOException {
      var reader = new FoodConfigurationReader(new StringReader(config));
      var map = reader.readConfiguration();
      Assertions.assertEquals(fish, map.get(FoodType.FISH), "Fish");
      Assertions.assertEquals(hay, map.get(FoodType.HAY), "Hay");
      Assertions.assertEquals(grain, map.get(FoodType.GRAIN), "Grain");
      Global.addPoints(0.5);
   }
   
   public static Stream<String> simpleInvalidConfigurations() {
      return Stream.of("9 HONEY", "FISH", "HAY 12", "1 FISH\n2 HAY\n3 GRAIN\n4", "1 FISH\nHAY 2", 
      "-1 FISH", "3HAY", "3 FISH 2 HAY" /* no newline */);
   }
   
   @ParameterizedTest
   @Order(2)
   @DisplayName("[Task 3a, 0.5p each] Should throw an exception for this invalid configuration")
   @MethodSource("simpleInvalidConfigurations")
   void constructorShouldThrowExceptionForInvalidConfiguration(String config) {
      var reader = new FoodConfigurationReader(new StringReader(config));
      Assertions.assertThrows(IllegalArgumentException.class, () -> reader.readConfiguration());
      Global.addPoints(0.5);
   }
   
   

}
