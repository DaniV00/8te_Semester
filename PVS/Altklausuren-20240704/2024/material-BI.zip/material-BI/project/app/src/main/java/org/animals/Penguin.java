package org.animals;

// 1a) TODO: inherit from Animal and implement
// 1c) TODO: add create
public class Penguin {

   public Food getFood() {
      // 1b) TODO: implement
      return null;
   }  

   public String getType() {
      return null;
   }

   public String getName() {
      return null;
   }

   public int getAge() {
      return -1;
   }
  
}
