package org.animals;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import org.animals.Food.FoodType;

// 2a) TODO: Add preserve and update constructor
public class NaturalPreserve<A> {
   private final int maxCapacity;
   private final Collection<A> animals;
   
   public NaturalPreserve(int maxCapacity) {
      this.maxCapacity = maxCapacity;
      this.animals = null;
   }

   public boolean addAnimal(A animal) {
      // TODO: 2b) add the animal if capacity allows
      return false;
   }
   
      
   public Optional<A> getHungriestAnimal() {
      // 2c) TODO: return the hungriest animal or empty if there are no animals
      return null;
   }

   public void feedAnimals(Map<FoodType, Integer> foodQuantities) {
      // 2d) TODO: check if we have enough food for all current animals, only if so, modify the map and feed the animals
      throw new UnsupportedOperationException("Not yet implemented");
   }
   
   
   public int feedAsOftenAsPossible(Map<FoodType, Integer> foodQuantities) {
      // 2e) TODO: feed the animals as often as possible, return the number of times, check for infinite loop
      return -42;
   }
   

   public Collection<A> getAnimals() {
      return this.animals;
   }
}
