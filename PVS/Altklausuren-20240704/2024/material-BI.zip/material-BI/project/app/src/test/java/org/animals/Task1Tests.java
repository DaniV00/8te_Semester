/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.animals;

import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ Global.class })
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task1Tests {
   
   @Test
   @Order(1)
   @DisplayName("[Task 1a, 0.5p] Penguin has a single (String, int) constructor")
   void penguinHasWantedConstructor() {
      var ctors = Penguin.class.getDeclaredConstructors();
      Assertions.assertEquals(1, ctors.length, "Penguin should have a single constructor");
      var ctor = ctors[0];
      var params = ctor.getParameters();
      Assertions.assertEquals(2, params.length, "Penguin constructor should have 2 parameters");
      var fst = params[0];
      Assertions.assertEquals(String.class, fst.getType(), "Penguin constructor first parameter should be a String");
      var snd = params[1];
      Assertions.assertEquals(int.class, snd.getType(), "Penguin constructor second parameter should be an int");
      Global.addPoints(0.5);
   }
   
   @Test
   @Order(2)
   @DisplayName("[Task 1a, 1p] The Penguin constructor should assign the fields")
   void penguinConstructorAssignsFields() {
      var ctors = Penguin.class.getDeclaredConstructors();
      Assertions.assertEquals(1, ctors.length, "Penguin should have a single constructor");
      var ctor = ctors[0];
      try {
         var penguin = (Penguin) ctor.newInstance("Peter", 3);
         Assertions.assertEquals("Peter", penguin.getName(), "Penguin name should be as assigned");
         Assertions.assertEquals(3, penguin.getAge(), "Penguin age should be 3");
         Assertions.assertEquals("Penguin", penguin.getType(), "Penguin type should be 'Penguin'");
         Global.addPoints(1);
      } catch (Exception e) {
         Assertions.fail("Penguin constructor should not throw exceptions for good age");
      }
   }
   
   @Test
   @Order(3)
   @DisplayName("[Task 1b, 1p] Penguin should return the correct food")
   void penguinCorrectFood() {
      var ctors = Penguin.class.getDeclaredConstructors();
      Assertions.assertEquals(1, ctors.length, "Penguin should have a single constructor");
      var ctor = ctors[0];
      try {
         var penguin = (Penguin) ctor.newInstance("Hans", 12);
         var food = penguin.getFood();
         Assertions.assertEquals(GenericFood.FoodType.FISH, food.type(), "Penguin food should be FISH");
         Assertions.assertEquals(1, food.quantity(), "Penguin should require ONE fish");
         Global.addPoints(1);
      } catch (Exception e) {
         Assertions.fail("Penguin constructor should not throw exceptions for good age");
      }
   }
   
   @Test
   @Order(4)
   @DisplayName("[Task 1c, 1p] The penguin creator should create a penguin with age 0")
   void createNewPenguin() {
      var statics = Arrays.stream(Penguin.class.getDeclaredMethods()).filter(
            m -> Modifier.isStatic(m.getModifiers())).toList();
      Assertions.assertEquals(1, statics.size(), "Penguin should have a static method");      
      var create = statics.get(0);
      Assertions.assertEquals("create", create.getName(), "Penguin static method should be named 'create'");
      Assertions.assertEquals(Penguin.class, create.getReturnType(), "Penguin static method should return a Penguin");
      var params = create.getParameters();
      Assertions.assertEquals(1, params.length, "Penguin static method should take a single parameter");
      Assertions.assertEquals(String.class, params[0].getType(), "Penguin static method should take a String parameter");
      try {
         var penguin = (Penguin) create.invoke(null, "Hans");
         Assertions.assertEquals("Hans", penguin.getName(), "Penguin name should be as assigned");
         Assertions.assertEquals(0, penguin.getAge(), "Penguin age should be 0");
         Assertions.assertEquals("Penguin", penguin.getType(), "Penguin type should be 'Penguin'");
         Global.addPoints(1);
      } catch (Exception e) {
         Assertions.fail("Penguin creator should not throw exceptions");
      }
   }
   
   @Test
   @Order(5)
   @DisplayName("[Task 1d, 0.5p] There should be no animals with negative age")
   void ageMustBePositive() {
      Assertions.assertThrows(IllegalArgumentException.class, () -> {
         new Animal(null, null, -1) { GenericFood getFood() { return null; } };
      }, "Animal should not allow negative age");
      Assertions.assertThrows(IllegalArgumentException.class, () -> {
         new Animal(null, null, -5) { GenericFood getFood() { return null; } };
      }, "Animal should not allow negative age");
      Global.addPoints(0.5);
   }

}
