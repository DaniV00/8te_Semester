package org.explorer;

import java.util.List;

// 2a) TODO: start with no trips and add interface
public class SpaceRoundTripMission {
    private final List<Trip> trips;

    public SpaceRoundTripMission() {
        trips = null;
    }

    public void addTrip(final Trip trip) {
        // 2b) TODO: add the trip to the list
        // 2c) TODO: fail if the mission has already started
    }

    /**
     * @return given that the duration of each trip is positive, the total duration of all trips is positive as well
     * @throws InvalidMissionException if the mission is either empty or not a valid cycle
     */
    public double start() throws InvalidMissionException {
        // 2c) TODO: implement start
        return 0.0;
    }


    public double estimatedCost(double fuelPricePerDay, double pricePerCrewMember) {
        // 2d) TODO: calculate the total cost of the mission
        return 0.0;
    }

    public SpaceMission shortenToDuration(double duration) {
        // 2e) TODO: return a new mission with a total duration limited to the given duration
        return null;
    }
    
    
    public List<Trip> trips() {
        return trips;
    }
}
