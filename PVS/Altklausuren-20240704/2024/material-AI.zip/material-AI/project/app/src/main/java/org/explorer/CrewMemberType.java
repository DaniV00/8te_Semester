package org.explorer;

public enum CrewMemberType {
    COMMANDER,
    PILOT,
    DOCTOR,
    ENGINEER,
    SCIENTIST
}
