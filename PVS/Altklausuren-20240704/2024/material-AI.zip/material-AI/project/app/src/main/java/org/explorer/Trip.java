package org.explorer;

/**
 * A Trip is part of a {@link SpaceMission}, representing a journey from one planet to another.
 */
public interface Trip {
    /** name of the starting planet of the trip */
    String start();
    /** name of the destination planet of the trip */
    String destination();
    /** duration of the trip in days, must be positive or zero */
    double duration();
    /** get the crew of the trip */
    Crew crew();
}
