package org.explorer;

import java.io.OutputStream;

public class SpacePrinter {
    public final OutputStream out;

    public SpacePrinter(OutputStream out) {
        // 3a) TODO: make the stream buffered
        this.out = out;
    }

    public void printTrip(Trip trip) {
        // 3b) TODO: print the trip in the format "start,destination,duration,crewSize"
    }

    public void printMission(SpaceMission mission) {
        // 3c) TODO: print all trips of the mission
    }
}
