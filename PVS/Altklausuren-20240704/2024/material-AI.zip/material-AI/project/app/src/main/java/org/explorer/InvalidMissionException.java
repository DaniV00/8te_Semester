package org.explorer;

/**
 * Thrown when a {@link SpaceMission} is invalid, always giving a reason why.
 */
public class InvalidMissionException extends Exception {
   public InvalidMissionException(String message) {
      super(message);
   }
}
