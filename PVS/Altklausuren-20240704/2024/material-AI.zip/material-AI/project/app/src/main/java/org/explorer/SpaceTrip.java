package org.explorer;

// 1a); b); c) TODO: implement this space trip
// you can replace the code of this class

public class SpaceTrip implements Trip {

   public SpaceTrip(Object... args) {
      throw new UnsupportedOperationException("Not implemented yet");
   }

   public String start() {
      return null;
   }

   public String destination() {
      return null;
   }

   public double duration() {
      return 0;
   }

   public Crew crew() {
      return null;
   }
}
