package org.animals;

public record GenericFood(FoodType type, int quantity) implements Food {
}
