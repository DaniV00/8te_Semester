package org.animals;

public interface Food {
      public FoodType type();
      public int quantity();
      
      public enum FoodType {
         FISH, HAY, GRAIN
   }
}
