package org.animals;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

import org.animals.Food.FoodType;

// 2a) TODO: Add preserve and update constructor
public class NaturalPreserve<A extends Animal> implements Preserve<A> {
   private final int maxCapacity;
   private final Collection<A> animals;
   
   public NaturalPreserve(int maxCapacity) {
      this.maxCapacity = maxCapacity;
      this.animals = new ArrayList<>(this.maxCapacity /* optional */);
   }

   public boolean addAnimal(A animal) {
      // TODO: 2b) add the animal if capacity allows
      if (this.animals.size() >= this.maxCapacity) {
         return false;
      }
      this.animals.add(animal);
      return true;
   }
   
      
   public Optional<A> getHungriestAnimal() {
      // 2c) TODO: return the hungriest animal or empty if there are no animals
      return this.animals.stream().max((a1, a2) -> a1.getFood().quantity() - a2.getFood().quantity());
   }

   public void feedAnimals(Map<FoodType, Integer> foodQuantities) {
      // 2d) TODO: check if we have enough food for all current animals, only if so, modify the map and feed the animals
      if(!hasEnoughFood(foodQuantities)) {
         throw new IllegalArgumentException("Not enough food for all animals");
      }
      for (var animal : this.animals) {
         var food = animal.getFood();
         foodQuantities.put(food.type(), foodQuantities.get(food.type()) - food.quantity());
      }
   }
   
   private boolean hasEnoughFood(Map<FoodType, Integer> foodQuantities) {
      var requirements = new EnumMap<FoodType, Integer>(FoodType.class);
      for (var animal : this.animals) {
         var food = animal.getFood();
         requirements.put(food.type(), requirements.getOrDefault(food.type(), 0) + food.quantity());
      }
      for (var entry : requirements.entrySet()) {
         if (foodQuantities.getOrDefault(entry.getKey(), 0) < entry.getValue()) {
            return false;
         }
      }
      return true;
   }
   
   public int feedAsOftenAsPossible(Map<FoodType, Integer> foodQuantities) {
      // 2e) TODO: feed the animals as often as possible, return the number of times, check for infinite loop
      if(this.animals.isEmpty() || this.animals.stream().anyMatch(a -> a.getFood().quantity() <= 0)) {
         throw new IllegalStateException("Would feed forever");
      }
      var counts = 0;
      while(hasEnoughFood(foodQuantities)) {
         feedAnimals(foodQuantities);
         counts++;
      }
      return counts;
   }
   

   public Collection<A> getAnimals() {
      return this.animals;
   }
}
