package org.animals;

import java.io.BufferedReader;
import java.util.EnumMap;
import java.io.IOException;
import java.util.Map;
import java.io.Reader;

import org.animals.Food.FoodType;


public class FoodConfigurationReader {
   // Note: You can change the type of this attribute
   private BufferedReader reader;
   
   public FoodConfigurationReader(Reader reader) {
      this.reader = new BufferedReader(reader);
   }
   
   public Map<FoodType, Integer> readConfiguration() throws IOException {
      // 3a) TODO: Implement this method to read the configuration from the reader
      var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.FISH, 0);
      foodQuantities.put(FoodType.HAY, 0);
      foodQuantities.put(FoodType.GRAIN, 0);

      String line = null;
      while ((line = reader.readLine()) != null) {
         if(line.isBlank()) {
            continue;
         }
         String[] parts = line.split(" ");
         if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid configuration line: " + line);
         }
         int quantity = Integer.parseInt(parts[0]);
         
         if(quantity < 0) {
            throw new IllegalArgumentException("Invalid quantity: " + quantity);
         }
         
         // or value of
         FoodType type = switch (parts[1]) {
            case "FISH" -> FoodType.FISH;
            case "HAY" -> FoodType.HAY;
            case "GRAIN" -> FoodType.GRAIN;
            default -> throw new IllegalArgumentException("Invalid food type: " + parts[0]);
         };
         foodQuantities.put(type, foodQuantities.get(type) + quantity);
      }
      
      return foodQuantities;
   }
}
