/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */
package org.animals;

import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

import com.google.common.util.concurrent.AtomicDouble;

public class Global implements BeforeAllCallback {
   public static AtomicDouble points = new AtomicDouble(0);
   private static boolean started = false;
   
   @Override
   public void beforeAll(ExtensionContext context) {
      if (!started) {
          started = true;
          Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("=".repeat(80));
            System.out.println("Points: " + Math.max(0, points.get()));
            System.out.println("=".repeat(80));
         }));
      }
   }
   
   public static void addPoints(double delta) {
      points.addAndGet(delta);
   }
}
