package org.animals;

/** Represents an animal to be put into a preserve */
public abstract class Animal {
    private final String type;
    private final String name;
    private final int age;
    
    protected Animal(String type, String name, int age) {
        if (age < 0) {
            throw new IllegalArgumentException("Age must be non-negative");
        }
        this.type = type;
        this.name = name;
        this.age = age;
    }
    
    public String getType() {
        return type;
    }
    
    public String getName() {
        return name;
    }
    
    public int getAge() {
        return age;
    }
    abstract Food getFood();
}
