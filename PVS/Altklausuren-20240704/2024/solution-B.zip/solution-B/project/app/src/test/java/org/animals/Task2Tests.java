/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.animals;

import java.util.EnumMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.animals.Food.FoodType;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;

@ExtendWith({ Global.class })
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task2Tests {
   
   @Test
   @Order(0)
   @DisplayName("[Task 2a, 0.5p] The NaturalPreserve should only implement Preserve")
   void naturalPreserveShouldImplementPreserve() {
      final var preserve = NaturalPreserve.class.getInterfaces();
      Assertions.assertTrue(preserve.length == 1 && preserve[0] == Preserve.class, "NaturalPreserve should (only) implement Preserve");
      Global.addPoints(0.5);
   }
   
   @Test
   @Order(1)
   @DisplayName("[Task 2a, 1p] The NaturalPreserve constructor should make an empty collection")
   void constructorShouldCreateAnEmptyCollection() {
      final var p = new NaturalPreserve<>(10);
      final var animals = p.getAnimals();
      Assertions.assertNotNull(animals, "The animals collection should not be null");
      Assertions.assertTrue(animals.isEmpty(), "The animals collection should be empty");
      Global.addPoints(1);
   }
   
   @Test
   @Order(2)
   @DisplayName("[Task 2b, 0.5p] Adding a single animal to the NaturalPreserve should work")
   void addingSingleAnimal() {
      final var p = new NaturalPreserve<>(10);
      final var animals = p.getAnimals();
      p.addAnimal(Animals.horsie);
      Assertions.assertEquals(1, animals.size(), "The animals collection should have 1 element");
      Assertions.assertTrue(animals.contains(Animals.horsie), "The animals collection should contain the added animal");
      Global.addPoints(0.5);
   }
   
   @Test
   @Order(3)
   @DisplayName("[Task 2b, 0.75p] Adding a multiple animals to the NaturalPreserve should work (including return type)")
   void addingMultipleAnimals() {
      final var p = new NaturalPreserve<>(10);
      final var animals = p.getAnimals();
      final var success = p.addAnimal(Animals.horsie);
      final var success2 = p.addAnimal(Animals.pengu);
      final var success3 = p.addAnimal(Animals.eleph);
      Assertions.assertTrue(success, "Adding a single animal should succeed");
      Assertions.assertTrue(success2, "Adding another animal should succeed");
      Assertions.assertTrue(success3, "Adding a third animal should succeed");
      Assertions.assertEquals(3, animals.size(), "The animals collection should have 3 elements");
      Assertions.assertTrue(animals.contains(Animals.horsie), "The animals collection should contain the added horse");
      Assertions.assertTrue(animals.contains(Animals.pengu), "The animals collection should contain the added penguin");
      Assertions.assertTrue(animals.contains(Animals.eleph), "The animals collection should contain the added elephant");
      Global.addPoints(0.75);
   }
   
   @Test
   @Order(4)
   @DisplayName("[Task 2b, 0.25p] Adding more animals than the capacity should fail (no capacity)")
   void addingMoreAnimalsThanCapacityZeroShouldFail() {
      final var p = new NaturalPreserve<>(0);
      final var add = p.addAnimal(Animals.horsie);
      Assertions.assertFalse(add, "Adding a third animal should fail");
      final var animals = p.getAnimals();
      Assertions.assertTrue(animals.isEmpty(), "The animals collection should be empty");
      Global.addPoints(0.25);
   }
   
   @Test
   @Order(5)
   @DisplayName("[Task 2b, 0.5p] Adding more animals than the capacity should fail")
   void addingMoreAnimalsThanCapacityShouldFail() {
      final var p = new NaturalPreserve<>(2);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.pengu);
      p.addAnimal(Animals.eleph);
      p.addAnimal(Animals.eleph2);
      final var animals = p.getAnimals();
      Assertions.assertEquals(2, animals.size(), "The animals collection should have 2 elements");
      Assertions.assertTrue(animals.contains(Animals.horsie), "The animals collection should contain the added horse");
      Assertions.assertTrue(animals.contains(Animals.pengu), "The animals collection should contain the added penguin");
      Global.addPoints(0.5);
   }
   
   @Test
   @Order(6)
   @DisplayName("[Task 2c, 1.5p] Should present the hungriest animal")
   void shouldPresentTheHungriestAnimal() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.pengu);
      p.addAnimal(Animals.eleph);
      final var h = p.getHungriestAnimal();
      Assertions.assertNotNull(h, "The hungriest animal should not be null");
      Assertions.assertTrue(h.isPresent(), "There should be a hungriest animal");
      Assertions.assertEquals(Animals.eleph, h.get(), "The elephant should be the hungriest");
      Global.addPoints(1.5);
   }
   
   @Test
   @Order(7)
   @DisplayName("[Task 2c, 1p] The hungriest should work if multiple animals are equally hungry")
   void theHungriestIfMultipleAnimalsAreEquallyHungry() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.eleph);
      p.addAnimal(Animals.eleph2);
      final var h = p.getHungriestAnimal();
      Assertions.assertNotNull(h, "The hungriest animal should not be null");
      Assertions.assertTrue(h.isPresent(), "There should be a hungriest animal");
      Assertions.assertTrue(h.get() == Animals.eleph || h.get() == Animals.eleph2, "One of the elephants should be the hungriest");
      Global.addPoints(1.5);
   }
   
   @Test
   @Order(8)
   @DisplayName("[Task 2c, 0.5p] The hungriest should work without animals")
   void theHungriestWithoutAnimals() {
      final var p = new NaturalPreserve<>(42);
      final var h = p.getHungriestAnimal();
      Assertions.assertNotNull(h, "The hungriest animal should not be null");
      Assertions.assertTrue(h.isEmpty(), "There should be no hungriest animal");
      Global.addPoints(0.5);
   }
   
   
   
   @Test
   @Order(9)
   @DisplayName("[Task 2d, 1p] Feeding no animals should work")
   void feedingNoAnimals() {
      final var p = new NaturalPreserve<>(10);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      Assertions.assertDoesNotThrow(() -> p.feedAnimals(foodQuantities));
      Global.addPoints(1);
   }
   
   @Test
   @Order(10)
   @DisplayName("[Task 2d, 1.5p] Feeding a single animal should work and remove the food")
   void feedingSingleAnimal() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 12);
      p.feedAnimals(foodQuantities);
      Assertions.assertEquals(7, foodQuantities.get(FoodType.HAY), "The food quantity should be reduced by the desired amount");
      p.feedAnimals(foodQuantities);
      Assertions.assertEquals(2, foodQuantities.get(FoodType.HAY), "Should work a second time");
      Global.addPoints(1.5);
   }
   
   @Test
   @Order(11)
   @DisplayName("[Task 2d, 1.5p] Feeding multiple animals should work and remove the food")
   void feedingMultipleAnimals() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.pengu);
      p.addAnimal(Animals.eleph);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 12);
      foodQuantities.put(FoodType.FISH, 3);
      foodQuantities.put(FoodType.GRAIN, 10);
      p.feedAnimals(foodQuantities);
      Assertions.assertEquals(7, foodQuantities.get(FoodType.HAY));
      Assertions.assertEquals(1, foodQuantities.get(FoodType.FISH));
      Assertions.assertEquals(0, foodQuantities.get(FoodType.GRAIN));
      Global.addPoints(1.5);
   }
   
   @Test
   @Order(12)
   @DisplayName("[Task 2d, 1.5p] Feeding more animals than the food should fail, leaving the map untouched")
   void feedingMoreAnimalsThanFoodShouldFail() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.pengu);
      p.addAnimal(Animals.eleph);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 12);
      foodQuantities.put(FoodType.FISH, 3);
      Assertions.assertThrows(IllegalArgumentException.class, () -> p.feedAnimals(foodQuantities));
      Assertions.assertEquals(12, foodQuantities.get(FoodType.HAY), "The food quantity should be untouched");
      Assertions.assertEquals(3, foodQuantities.get(FoodType.FISH), "The food quantity should be untouched");
      Global.addPoints(1.5);
   }
   
      
   @Test
   @Order(13)
   @DisplayName("[Task 2d, 0.5p] Feeding should fail if all animals can not be fed")
   void feedingShouldFailIfAllAnimalsCanNotBeFed() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.eleph);
      p.addAnimal(Animals.eleph2);
      p.addAnimal(Animals.eleph3);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      Assertions.assertThrows(IllegalArgumentException.class, () -> p.feedAnimals(foodQuantities));
      Assertions.assertTrue(foodQuantities.isEmpty(), "The food quantity should be untouched");
      Global.addPoints(0.5);
   }
      
   @Test
   @Order(15)
   @DisplayName("[Task 2e, 2p] Feeding as often as possible with multiple rounds")
   void feedingAsOftenAsPossible() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.horsie);
      p.addAnimal(Animals.pengu);
      p.addAnimal(Animals.eleph);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 16);
      foodQuantities.put(FoodType.FISH, 4);
      foodQuantities.put(FoodType.GRAIN, 21);
      final var count = p.feedAsOftenAsPossible(foodQuantities);
      Assertions.assertEquals(2, count, "Should be able to feed twice");
      Assertions.assertEquals(6, foodQuantities.get(FoodType.HAY));
      Assertions.assertEquals(0, foodQuantities.get(FoodType.FISH));
      Assertions.assertEquals(1, foodQuantities.get(FoodType.GRAIN));
      Global.addPoints(2);
   }
   
   @Test
   @Order(14)
   @DisplayName("[Task 2e, 1.5p] Feeding no animals should not cause an infinite loop")
   void repeatedFeedingWithoutAnimals() {
      final var p = new NaturalPreserve<>(10);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 42);
      foodQuantities.put(FoodType.FISH, 6);
      foodQuantities.put(FoodType.GRAIN, 4);
      final var result = new AtomicInteger(-1);
      Assertions.assertThrows(IllegalStateException.class, () -> {
         result.set(p.feedAsOftenAsPossible(foodQuantities));
      });
      Assertions.assertEquals(-1, result.get(), "Should not be able to feed any animals");
      Global.addPoints(1.5);
   }
   
   @Test
   @Order(14)
   @DisplayName("[Task 2e, 1.5p] Feeding animals that do not require food should not create an infinite loop")
   void repeatedFeedingWithoutFood() {
      final var p = new NaturalPreserve<>(10);
      p.addAnimal(Animals.dietPengu);
      p.addAnimal(Animals.pengu2);
      final var foodQuantities = new EnumMap<FoodType, Integer>(FoodType.class);
      foodQuantities.put(FoodType.HAY, 42);
      foodQuantities.put(FoodType.FISH, 6);
      foodQuantities.put(FoodType.GRAIN, 4);
      final var result = new AtomicInteger(-1);
      Assertions.assertThrows(IllegalStateException.class, () -> {
         result.set(p.feedAsOftenAsPossible(foodQuantities));
      });
      Assertions.assertEquals(-1, result.get(), "Should not be able to feed any animals");
      Global.addPoints(1.5);
   }
   

}
