package org.animals;

import org.animals.Food.FoodType;
// 1a) TODO: inherit from Animal and implement
// 1c) TODO: add create
public class Penguin extends Animal {
      public Penguin(String name, int age) {
         super("Penguin", name, age);
      }
      
      public Food getFood() {
         return new GenericFood(FoodType.FISH, 1);
      }  
      
      
      public static Penguin create(String name) {
         return new Penguin(name, 0);
      }
}
