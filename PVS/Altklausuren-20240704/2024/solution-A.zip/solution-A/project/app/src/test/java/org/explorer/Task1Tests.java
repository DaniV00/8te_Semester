/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.explorer;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Arrays;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

@ExtendWith({ Global.class })
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task1Tests {
   
   private static Stream<Arguments> requiredFields() {
      return Stream.of(
         Arguments.of("crew", Set.of(Crew.class)),
         Arguments.of("destination", Set.of(String.class)),
         Arguments.of("duration", Set.of(Double.class, double.class)),
         Arguments.of("start", Set.of(String.class))
      );
   }
   
   @ParameterizedTest
   @Order(1)
   @MethodSource("requiredFields")
   @DisplayName("[Task 1a, 0.5p each] SpaceTrip has required fields")
   void tripHasRequiredKeyNames(String name, Set<Class<?>> types) {
      final var fields = Arrays.stream(SpaceTrip.class.getDeclaredFields())
              .collect(Collectors.toMap(Field::getName, f -> f));

      Assertions.assertTrue(fields.containsKey(name), "Missing field: " + name);
      Assertions.assertTrue(types.contains(fields.get(name).getType()), "Invalid type for field: " + name + ", expected one of: " + types + ", found: " + fields.get(name).getType());
      Assertions.assertEquals(Modifier.FINAL, (fields.get(name).getModifiers() & Modifier.FINAL), "Field " + name + " must be final");

      Global.addPoints(0.5);
   }

   @Test
   @Order(2)
   @DisplayName("[Task 1a, 0.5p] SpaceTrip has exactly 4 fields")
   void tripHasExactly4Fields() {
        final var fields = SpaceTrip.class.getDeclaredFields();
        Assertions.assertEquals(4, fields.length, "SpaceTrip should have exactly 4 fields");
        Global.addPoints(0.5);
   }

   @Test
   @Order(3)
   @DisplayName("[Task 1b, 0.5p] SpaceTrip has a full constructor")
    void tripHasFullConstructor() {
      final var constructors = SpaceTrip.class.getDeclaredConstructors();
      Assertions.assertEquals(1, constructors.length, "SpaceTrip should have exactly 1 constructor");

      // test instantiate to validate order
      final var crew = Trips.crewOfSize(5);
      final var trip = new SpaceTrip("Earth", "Mars", 10, crew);
      Assertions.assertEquals("Earth", trip.start());
      Assertions.assertEquals("Mars", trip.destination());
      Assertions.assertEquals(10, trip.duration());
      Assertions.assertEquals(crew, trip.crew());

      Global.addPoints(0.5);
   }

   @Test
   @Order(4)
   @DisplayName("[Task 1c, 1p] SpaceTrip constructor throws IllegalArgumentException for negative duration")
    void tripConstructorThrowsIllegalArgumentExceptionForNegativeDuration() {
      for (int i = -10; i < 0; i++) {
         final int duration = i;
         Assertions.assertThrows(IllegalArgumentException.class, () -> new SpaceTrip("Earth", "Mars", duration, Trips.crewOfSize(5)));
      }
      Global.addPoints(1);
    }

}
