/**
 * == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM ==
 */

package org.explorer;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.explorer.Trips.*;

@ExtendWith({Global.class})
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task3Tests {

    private static Pattern pat_m = Pattern.compile("Earth,Mars,100(\\.00?)?,5");

    private abstract static class SpyingOutputStream extends OutputStream {
        public StackTraceElement[] lastStackTrace = null;
    }

    private SpyingOutputStream makeCollector() {
        return new SpyingOutputStream() {
            private final StringBuilder string = new StringBuilder();

            @Override
            public void write(int b) {
                // get the stack trace
                this.lastStackTrace = Thread.currentThread().getStackTrace();
                this.string.append((char) b);
            }

            public String toString() {
                return this.string.toString();
            }
        };
    }

    @Test
    @Order(1)
    @DisplayName("[Task 3a, 1p] The printer should be buffered")
    void printerShouldHaveWantedDecorations() throws IOException {
        try (final var out = makeCollector()) {
            final var writer = new SpacePrinter(out);

            // update the stack trace in the spy
            writer.out.write(0);
            writer.out.flush();

            var classes = Arrays.stream(out.lastStackTrace).map(StackTraceElement::getClassName).anyMatch(s -> s.contains(
                Arrays.stream(new Character[] { 66, 117, 102, 102,  101, 114, 101, 100 }).map(String::valueOf).collect(Collectors.joining())
            ));
            Assertions.assertTrue(classes);
            Global.addPoints(1);
        }
    }

    @Test
    @Order(2)
    @DisplayName("[Task 3b, 1.5p] Printing a single trip should work")
    void printingSingleTripShouldWork() throws IOException {
        try (final var out = makeCollector()) {
            final var writer = new SpacePrinter(out);

            writer.printTrip(trip1);
            writer.out.flush();

            final var input = out.toString().trim();
            Assertions.assertTrue(pat_m.matcher(input).matches(), "Expected output to match pattern: " + pat_m.pattern());
            Global.addPoints(1.5);
        }
    }

    private static Pattern pat_n = Pattern.compile("Mars,Jupiter,75(\\.00?)?,5");
    private static Pattern pat_o = Pattern.compile("Jupiter,Earth,50(\\.00?)?,3");
    
    @Test
    @Order(3)
    @DisplayName("[Task 3b, 0.5p] Printing a single trip should work multiple times")
    void printingSingleTripShouldWorkMultipleTimes() throws IOException {
        try (final var out = makeCollector()) {
            final var writer = new SpacePrinter(out);

            writer.printTrip(trip1);
            writer.printTrip(trip2);
            writer.printTrip(trip3);
            writer.out.flush();

            var lines = out.toString().split("\n\r?");

            Assertions.assertEquals(3, lines.length);
            Assertions.assertTrue(pat_m.matcher(lines[0]).matches(), "Expected output to match pattern: " + pat_m.pattern());
            Assertions.assertTrue(pat_n.matcher(lines[1]).matches(), "Expected output to match pattern: " + pat_n.pattern());
            Assertions.assertTrue(pat_o.matcher(lines[2]).matches(), "Expected output to match pattern: " + pat_o.pattern());
            Global.addPoints(0.5);
        }
    }

    @Test
    @Order(4)
    @DisplayName("[Task 3c, 2p] Printing a mission should work")
    void printingMissionShouldWork() throws IOException {
        try (final var out = makeCollector()) {
            final var writer = new SpacePrinter(out);

            writer.printMission(new SpaceMission() {
                public void addTrip(Trip trip) {}
                public List<Trip> trips() { return List.of(trip1, trip3, trip2); }
                public double start() { return 0; }
                public double estimatedCost(double fuelPricePerDay, double pricePerCrewMember) { return 0; }
                public SpaceMission shortenToDuration(double duration) { return null; }
            });
            writer.out.flush();

            var lines = out.toString().split("\n\r?");

            Assertions.assertEquals(3, lines.length);
            Assertions.assertTrue(pat_m.matcher(lines[0]).matches(), "Expected output to match pattern: " + pat_m.pattern());
            Assertions.assertTrue(pat_o.matcher(lines[1]).matches(), "Expected output to match pattern: " + pat_o.pattern());
            Assertions.assertTrue(pat_n.matcher(lines[2]).matches(), "Expected output to match pattern: " + pat_n.pattern());
            Global.addPoints(2);
        }
    }

}
