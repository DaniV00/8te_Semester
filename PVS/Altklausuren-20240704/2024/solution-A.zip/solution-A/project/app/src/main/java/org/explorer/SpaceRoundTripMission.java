package org.explorer;

import java.util.ArrayList;
import java.util.List;

// 2a) TODO: start with no trips and add interface
public class SpaceRoundTripMission  implements SpaceMission {
    private final List<Trip> trips;
    private boolean started = false;

    public SpaceRoundTripMission() {
        trips = new ArrayList<>();
    }

    public void addTrip(final Trip trip) {
        // 2b) TODO: add the trip to the list
        // 2c) TODO: fail if the mission has already started
        if (started) {
            throw new IllegalStateException("Mission already started");
        }
        trips.add(trip);
    }

    /**
     * @return given that the duration of each trip is positive, the total duration of all trips is positive as well
     * @throws InvalidMissionException if the mission is either empty or not a valid cycle
     */
    public double start() throws InvalidMissionException {
        // 2c) TODO: implement start
        if(trips.isEmpty()) {
            throw new InvalidMissionException("Mission is empty");
        }
        if(!isCycle()) {
            throw new InvalidMissionException("Mission is not a valid cycle");
        }

        started = true;
        return trips.stream().mapToDouble(Trip::duration).sum();
    }

    private boolean isCycle() {
        final var start = trips.getFirst().start();
        var current = trips.getFirst().destination();
        for (int i = 1; i < trips.size(); i++) {
            if (!current.equals(trips.get(i).start())) {
                return false;
            }
            current = trips.get(i).destination();
        }
        return current.equals(start);
    }

    public double estimatedCost(double fuelPricePerDay, double pricePerCrewMember) {
        // 2d) TODO: calculate the total cost of the mission
        return trips.stream()
                .mapToDouble(trip -> {
                    var d = Math.ceil(trip.duration());
                    return d * fuelPricePerDay + trip.crew().numberOfMembers() * d * pricePerCrewMember;
                })
                .sum();
    }

    public SpaceMission shortenToDuration(double duration) {
        // 2e) TODO: return a new mission with a total duration limited to the given duration
        var newMission = new SpaceRoundTripMission();
        var currentDuration = 0.0;
        Trip lastTrip = null;
        for (var trip : trips) {
            if (currentDuration + trip.duration() <= duration) {
                newMission.addTrip(trip);
                currentDuration += trip.duration();
            } else {
                if(lastTrip != null) {
                    var newTrip = new SpaceTrip(lastTrip.destination(), trips.getFirst().start(), currentDuration, lastTrip.crew());
                    newMission.addTrip(newTrip);
                }
                break;
            }
            lastTrip = trip;
        }
        return newMission;
    }
    
    
    public List<Trip> trips() {
        return trips;
    }
}
