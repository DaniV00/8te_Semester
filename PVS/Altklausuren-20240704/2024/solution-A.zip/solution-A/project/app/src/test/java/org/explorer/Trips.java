package org.explorer;

import java.util.Arrays;

class Trips {
    protected static final Crew crewA = Crew.of(
        new CrewMemberInfo("Alice", CrewMemberType.COMMANDER, 45),
        new CrewMemberInfo("Bob", CrewMemberType.DOCTOR, 35),
        new CrewMemberInfo("Charlie", CrewMemberType.PILOT, 40),
        new CrewMemberInfo("Dave", CrewMemberType.ENGINEER, 38),
        new CrewMemberInfo("Eve", CrewMemberType.SCIENTIST, 30),
        new CrewMemberInfo("Faythe", CrewMemberType.PILOT, 32),
        new CrewMemberInfo("Grace", CrewMemberType.DOCTOR, 37),
        new CrewMemberInfo("Heidi", CrewMemberType.ENGINEER, 33),
        new CrewMemberInfo("Ivan", CrewMemberType.SCIENTIST, 28),
        new CrewMemberInfo("Judy", CrewMemberType.COMMANDER, 42),
        new CrewMemberInfo("Mallory", CrewMemberType.PILOT, 36),
        new CrewMemberInfo("Oscar", CrewMemberType.DOCTOR, 39),
        new CrewMemberInfo("Peggy", CrewMemberType.ENGINEER, 31)
    );

    protected static Crew crewOfSize(int size) {
        return Crew.of(Arrays.copyOf(crewA.members, size));
    }

    static final Trip trip1 = new Trip() {
        public String start() { return "Earth"; }
        public String destination() { return "Mars"; }
        public double duration() { return 100; }
        public Crew crew() { return crewOfSize(5); }
    };
    static final Trip trip2 = new Trip() {
        public String start() { return "Mars"; }
        public String destination() { return "Jupiter"; }
        public double duration() { return 75; }
        public Crew crew() { return crewOfSize(5); }
    };
    static final Trip trip3 = new Trip() {
        public String start() { return "Jupiter"; }
        public String destination() { return "Earth"; }
        public double duration() { return 50; }
        public Crew crew() { return crewOfSize(3); }
    };
    static final Trip trip4 = new Trip() {
        public String start() { return "Mars"; }
        public String destination() { return "Earth"; }
        public double duration() { return 100; }
        public Crew crew() { return crewOfSize(5); }
    };
    static final Trip trip5 = new Trip() {
        public String start() { return "Mars"; }
        public String destination() { return "Earth"; }
        public double duration() { return 3.5; }
        public Crew crew() {  return crewOfSize(12); }
    };

}
