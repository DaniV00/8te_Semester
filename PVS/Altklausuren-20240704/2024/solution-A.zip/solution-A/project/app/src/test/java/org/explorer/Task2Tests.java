/** == CHANGING THIS FILE IN ANY WAY RESULTS IN AN AUTOMATIC FAILURE OF THE EXAM == */

package org.explorer;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Timeout.ThreadMode;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static org.explorer.Trips.*;

@ExtendWith({ Global.class })
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Timeout(value = 10, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
class Task2Tests {
   
   @Test
   @Order(1)
   @DisplayName("[Task 2a, 1p] A new round trip must be empty")
   void newEmptyRoundTrip() {
       final var mission = new SpaceRoundTripMission();
       Assertions.assertEquals(0, mission.trips().size(), "A new round trip mission should be empty");
       Global.addPoints(1);
   }

    @Test
    @Order(2)
    @DisplayName("[Task 2a, 0.5p] SpaceRoundTripMission implements SpaceMission")
    void roundTripImplementsSpaceMission() {
       Assertions.assertEquals(1, SpaceRoundTripMission.class.getInterfaces().length, "SpaceRoundTripMission should implement SpaceMission");
       Assertions.assertEquals(SpaceMission.class, SpaceRoundTripMission.class.getInterfaces()[0], "SpaceRoundTripMission should implement SpaceMission");
       Global.addPoints(0.5);
    }

    @Test
    @Order(3)
    @DisplayName("[Task 2b, 0.5p] SpaceRoundTripMission allows to add a mission")
    void roundTripAddMission() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        Assertions.assertIterableEquals(List.of(trip1), mission.trips(), "SpaceRoundTripMission should have the added trip");
        Global.addPoints(0.5);
    }

    @Test
    @Order(4)
    @DisplayName("[Task 2b, 0.5p] SpaceRoundTripMission allows to add multiple missions")
    void roundTripAddMultipleMissions() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        mission.addTrip(trip3);
        Assertions.assertIterableEquals(List.of(trip1, trip2, trip3), mission.trips(), "SpaceRoundTripMission should have the added trips");
        Global.addPoints(0.5);
    }


    @Test
    @Order(5)
    @DisplayName("[Task 2c, 1.5p] SpaceRoundTripMission allows to start a valid mission")
    void roundTripStartValidMission() throws InvalidMissionException {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        mission.addTrip(trip3);
        Assertions.assertEquals(225, mission.start(), "SpaceRoundTripMission should have a total duration of 225");
        Global.addPoints(1.5);
    }

    @Test
    @Order(6)
    @DisplayName("[Task 2c, 1p] SpaceRoundTripMission throws InvalidMissionException when starting an empty mission")
    void roundTripStartEmptyMission() {
        final var mission = new SpaceRoundTripMission();
        Assertions.assertThrows(InvalidMissionException.class, mission::start);
        Global.addPoints(1);
    }

    @Test
    @Order(7)
    @DisplayName("[Task 2c, 1p] SpaceRoundTripMission can still add trips if a start fails")
    void canStillAddAfterFailedStart() {
        final var mission = new SpaceRoundTripMission();
        Assertions.assertThrows(InvalidMissionException.class, mission::start);
        mission.addTrip(trip1);
        Global.addPoints(1);
    }

    @Test
    @Order(8)
    @DisplayName("[Task 2c, 1p] SpaceRoundTripMission does not allow to add trips after start")
    void roundTripAddTripsAfterStart() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        mission.addTrip(trip3);
        Assertions.assertEquals(3, mission.trips().size(), "SpaceRoundTripMission should 3 trips");
        Assertions.assertDoesNotThrow(mission::start);
        Assertions.assertThrows(IllegalStateException.class, () -> mission.addTrip(trip1));
        Assertions.assertEquals(3, mission.trips().size(), "SpaceRoundTripMission should 3 trips");
        Global.addPoints(1);
    }

    private static Stream<Arguments> tripCycleConfigurations() {
        return Stream.of(
            Arguments.of(false, 0,   List.of(trip1)),
            Arguments.of(false, 0,   List.of(trip1, trip2)),
            Arguments.of(true,  200, List.of(trip1, trip4)),
            Arguments.of(true,  400, List.of(trip1, trip4, trip1, trip4)),
            Arguments.of(false, 0,   List.of(trip1, trip4, trip1, trip4, trip2)),
            Arguments.of(true,  425, List.of(trip1, trip2, trip3, trip1, trip4)),
            // cycle, but not linked
            Arguments.of(false, 0,   List.of(trip1, trip3, trip4))
        );
    }

    @ParameterizedTest
    @Order(9)
    @DisplayName("[Task 2c, 0.5p each] SpaceRoundTripMission does only work for cycles")
    @MethodSource("tripCycleConfigurations")
    void roundTripValidCycles(boolean valid, double expectedResult, List<Trip> trips) throws InvalidMissionException {
        final var mission = new SpaceRoundTripMission();
        trips.forEach(mission::addTrip);
        if (valid) {
            Assertions.assertTrue(mission.start() > 0);
            Assertions.assertEquals(expectedResult, mission.start(), 0.01D, "SpaceRoundTripMission should have a total duration of " + expectedResult);
        } else {
            Assertions.assertThrows(InvalidMissionException.class, mission::start);
        }
        Global.addPoints(0.5);
    }

    private static Stream<Arguments> tripCostConfiguration() {
        return Stream.of(
                Arguments.of(100,  1, 0,    List.of(trip1)),
                Arguments.of(875,  0, 1,    List.of(trip1, trip2)),
                Arguments.of(1200, 1, 1,    List.of(trip1, trip4)),
                Arguments.of(8000, 5, 3,    List.of(trip1, trip4, trip1, trip4)),
                Arguments.of(2076, 9, 42.5, List.of(trip5))
        );
    }

    @ParameterizedTest
    @Order(10)
    @DisplayName("[Task 2d, 0.5p each] SpaceRoundTripMission calculates estimated cost")
    @MethodSource("tripCostConfiguration")
    void roundTripEstimatedCost(double expectedResult, double pu, double pc, List<Trip> trips) {
        final var mission = new SpaceRoundTripMission();
        trips.forEach(mission::addTrip);
        Assertions.assertEquals(
                expectedResult, mission.estimatedCost(pu, pc), 0.01D,
                "SpaceRoundTripMission should have an estimated cost of " + expectedResult + "(price per unit: " + pu + ", price per crew member: " + pc + ")"
        );
        Global.addPoints(0.5);
    }


    @Test
    @Order(11)
    @DisplayName("[Task 2e, 0.5p] A limited mission should return a space mission")
    void limitToDurationShouldReturnASpaceMission() {
        final var mission = new SpaceRoundTripMission();
        final var limited = mission.shortenToDuration(100);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        Global.addPoints(0.5);
    }

    @Test
    @Order(12)
    @DisplayName("[Task 2e, 1p] Limiting without exceeding the duration should return the same number of trips")
    void limitToDurationShouldReturnSameNumberOfTrips() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        final var limited = mission.shortenToDuration(9999);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        final var limTrips = limited.trips();
        Assertions.assertEquals(2, limTrips.size(), "limitToDuration should return the same number of trips if the duration is not exceeded");
        // Access the trips and check if they are the same
        Assertions.assertIterableEquals(mission.trips(), limTrips, "limitToDuration should return the same trips if the duration is not exceeded");
        Global.addPoints(1);
    }

    @Test
    @Order(13)
    @DisplayName("[Task 2e, 1.5p] A mission should be a real copy")
    void missionShouldBeACopy() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        final var limited = mission.shortenToDuration(1000);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        Assertions.assertEquals(1, limited.trips().size(), "limitToDuration should return a new mission if the duration is not exceeded");
        mission.addTrip(trip2);
        Assertions.assertEquals(1, limited.trips().size(), "due to being copied, the limited mission should not change");
        Assertions.assertEquals(2, mission.trips().size(), "the mission should have a new trip");
        mission.shortenToDuration(0); // should not affect the main mission
        Assertions.assertEquals(2, mission.trips().size(), "the mission should have a new trip");
        Global.addPoints(1.5);
    }

    @Test
    @Order(14)
    @DisplayName("[Task 2e, 1.5p] Should return early, with a new trip, if the duration is exceeded")
    void shouldReturnEarlyWithNewTripIfDurationExceeded() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        final var limited = mission.shortenToDuration(100);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        final var limTrips = limited.trips();
        Assertions.assertEquals(2, limTrips.size(), "limitToDuration should return a new trip if the duration is exceeded");
        Assertions.assertEquals(trip1, limTrips.get(0), "The first trip should be the same");
        // Check if the new trip is correct
        final var newTrip = limTrips.get(1);
        Assertions.assertEquals(trip1.start(), newTrip.destination(), "The new trip should end at the first trip's start");
        Assertions.assertEquals(trip1.destination(), newTrip.start(), "The new trip should start at the last trip's end");
        Assertions.assertArrayEquals(trip1.crew().members, newTrip.crew().members, "The new trip should have the same crew size as the last trip");
        Assertions.assertEquals(trip1.duration(), newTrip.duration(), "The new trip should have the same duration as the sum of the previous trips");
        Global.addPoints(1.5);
    }

    @Test
    @Order(15)
    @DisplayName("[Task 2e, 1.5p] Should return an empty mission if the duration is insufficient")
    void shouldReturnEmptyMissionIfDurationInsufficient() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        final var limited = mission.shortenToDuration(99);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        final var limTrips = limited.trips();
        Assertions.assertTrue(limTrips.isEmpty(), "limitToDuration should return an empty mission if the duration is insufficient: " + limTrips);
        Global.addPoints(1.5);
    }

    @Test
    @Order(16)
    @DisplayName("[Task 2e, 1.5p] Should return early, keeping all previous trips")
    void shouldReturnEarlyKeepingAllPreviousTrips() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip2);
        mission.addTrip(trip3);
        final var limited = mission.shortenToDuration(175);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        final var limTrips = limited.trips();
        Assertions.assertEquals(3, limTrips.size(), "limitToDuration should return all previous trips if the duration is exceeded");
        Assertions.assertEquals(trip1, limTrips.get(0), "The first trip should be the same");
        Assertions.assertEquals(trip2, limTrips.get(1), "The second trip should be the same");
        // Check if the new trip is correct
        final var newTrip = limTrips.get(2);
        Assertions.assertEquals(trip1.start(), newTrip.destination(), "The new trip should end at the first trip's start");
        Assertions.assertEquals(trip2.destination(), newTrip.start(), "The new trip should start at the last trip's end");
        Assertions.assertArrayEquals(trip2.crew().members, newTrip.crew().members, "The new trip should have the same crew size as the last trip");
        Assertions.assertEquals(trip1.duration() + trip2.duration(), newTrip.duration(), "The new trip should have the same duration as the sum of the previous trips");
        Global.addPoints(1.5);
    }

    @Test
    @Order(17)
    @DisplayName("[Task 2e, 1.5p] Should return early, keeping all previous trips, even if used multiple times")
    void shouldReturnEarlyKeepingAllPreviousTripsIfUsedMultipleTimes() {
        final var mission = new SpaceRoundTripMission();
        mission.addTrip(trip1);
        mission.addTrip(trip4);
        mission.addTrip(trip1);
        mission.addTrip(trip3);
        final var limited = mission.shortenToDuration(300);
        Assertions.assertNotNull(limited, "limitToDuration should return a SpaceMission");
        final var limTrips = limited.trips();
        Assertions.assertEquals(4, limTrips.size(), "limitToDuration should return all previous trips if the duration is exceeded");
        Assertions.assertEquals(trip1, limTrips.get(0), "The first trip should be the same");
        Assertions.assertEquals(trip4, limTrips.get(1), "The second trip should be the same");
        Assertions.assertEquals(trip1, limTrips.get(2), "The third trip should be the same");
        // Check if the new trip is correct
        final var newTrip = limTrips.get(3);
        Assertions.assertEquals(trip1.start(), newTrip.destination(), "The new trip should end at the first trip's start");
        Assertions.assertEquals(trip1.destination(), newTrip.start(), "The new trip should start at the last trip's end");
        Assertions.assertArrayEquals(trip1.crew().members, newTrip.crew().members, "The new trip should have the same crew size as the last trip");
        Assertions.assertEquals(trip1.duration() + trip4.duration() + trip1.duration(), newTrip.duration(), "The new trip should have the same duration as the sum of the previous trips");
        Global.addPoints(1.5);
    }

}
