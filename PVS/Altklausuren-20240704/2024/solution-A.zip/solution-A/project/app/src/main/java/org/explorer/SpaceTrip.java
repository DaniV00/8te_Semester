package org.explorer;

// 1a); b); c) TODO: implement this space trip
// you can replace the code of this class

public record SpaceTrip(
   String start,
   String destination,
   double duration,
   Crew crew
) implements Trip {
   public SpaceTrip {
      if (duration < 0) {
         throw new IllegalArgumentException("duration must be >= 0");
      }
   }
}
