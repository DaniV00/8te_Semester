package org.explorer;

/** Represents a crew of a space mission. */
public class Crew {
    protected final CrewMemberInfo[] members;

    public Crew(CrewMemberInfo[] members) {
        this.members = members;
    }

    public static Crew of(CrewMemberInfo... members) {
        return new Crew(members);
    }

    public int numberOfMembers() {
        return members.length;
    }

    public CrewMemberInfo get(int i) {
        return members[i];
    }
}
