package org.explorer;

public class CrewMemberInfo {
    protected final String name;
    protected final CrewMemberType type;
    protected final int age;

    public CrewMemberInfo(String name, CrewMemberType type, int age) {
        this.name = name;
        this.type = type;
        this.age = age;
    }
}
