package org.explorer;

import java.util.List;

/**
 * A space mission consists of a series of trips.
 * When a new SpaceMission is constructed, it should contain NO trip,
 * allowing for adding trips with the {@link #addTrip(Trip)} method.
 * <p>
 * Once all desired trips are added, the mission can be started with {@link #start()}.
 */
public interface SpaceMission {
   /**
    * Add a new trip to the mission.
    * 
    * @throws IllegalStateException if the mission was already started with {@link #start()}
    */
   void addTrip(final Trip trip);

  /**
   * @return a list with all trips in the mission
   */
   List<Trip> trips();

    /**
     * Start the mission.
     * For this scenario we may assume, that a mission is never started multiple times.
     *
     * @return the total duration of the mission
     * @throws InvalidMissionException if the mission is invalid according to the rules of the specific mission
     * @implNote The rules for a valid mission are specific to each implementation.
     */
   double start() throws InvalidMissionException;

   /**
    * Estimate the cost of the mission in space credits.
    * <p>
    * Works for any kind of mission (even an invalid one)
    *
    * @param fuelPricePerDay    the price to be paid for fuel, per day
    * @param pricePerCrewMember the price per crew member, per day
    *
    * @apiNote For both units, fractions of days <b>should be considered as a full day</b>.
    *          In other words, if a trip lasts 1.5 days, the cost should be the same as if it lasted 2 days.
    */
   double estimatedCost(double fuelPricePerDay, double pricePerCrewMember);

   /**
    * Returns a NEW SpaceMission with a total duration of at most the given duration.
    * If this mission's duration is shorter than the given duration, this returns a (shallow) copy.
    * Otherwise, it returns only the trips up to a maximum total duration half of the given duration, adding
    * a new trip back to the starting planet, with the same crew size as the last trip, and a duration that
    * equals the duration of the trips so far.
    * <p>
    * If the duration is insufficient to handle the first trip, the method should return a new, empty mission.
    *
    * @implNote You do not have to verify if the mission is a valid cycle or not.
    */
   SpaceMission shortenToDuration(double duration);
}
