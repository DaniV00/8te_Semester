package org.explorer;

import java.io.BufferedOutputStream;
import java.io.PrintStream;
import java.io.OutputStream;

public class SpacePrinter {
    public final PrintStream out;

    public SpacePrinter(OutputStream out) {
        // 3a) TODO: make the stream buffered
        this.out = new PrintStream(new BufferedOutputStream(out));
        // print stream is optional
    }

    public void printTrip(Trip trip) {
        // 3b) TODO: print the trip in the format "start,destination,duration,crewSize"
        out.format("%s,%s,%.2f,%d%n", trip.start(), trip.destination(), trip.duration(), trip.crew().numberOfMembers());
    }

    public void printMission(SpaceMission mission) {
        // 3c) TODO: print all trips of the mission
        for(Trip trip : mission.trips()) {
            printTrip(trip);
        }
    }
}
